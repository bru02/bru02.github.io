let img, button1, button2, button3, input, dirs = [], canvas, i = 0; // Declare variable 'img'.
// All the paths
// Are we painting?
var painting = false;
// How long until the next circle
var next = 0;
// Where are we now and where were we?
var current;
let dir = 0;
var previous;
Vue.prototype.window_portal = window;
let lines = [[{ "x": 3, "y": 90.046875 }, { "x": 74, "y": 89.046875 }], [{ "x": 423, "y": 5.046875 }, { "x": 423, "y": 79.046875 }], [{ "x": 498, "y": 180.046875 }, { "x": 581, "y": 180 }], [{ "x": 540, "y": 180 }, { "x": 540, "y": 301.046875 }], [{ "x": 304, "y": 216.046875 }, { "x": 385, "y": 198.046875 }], [{ "x": 344, "y": 209.046875 }, { "x": 371, "y": 324 }], [{ "x": 478, "y": 320.046875 }, { "x": 477, "y": 394 }]];
Vue.component('editable', {
    template: '<label v-if="edit == false" @dblclick="editable&&(edit=true);"> {{content1}} </label><input v-else-if="edit == true" v-bind:value="content1" @keyup="update" v-on:blur= "check"  @keyup.enter="check" v-bind:pattern="pattern" class="validate">',
    props: ['content', 'editable', 'pattern'],
    data: function () {
        return {
            edit: false,
            content1: this.content + ""
        }
    },
    watch: {
        content: function (e) {
            this.content1 = e;
        }
    },
    methods: {
        update: function (e) {
            if (e.target.value) {
                this.$emit('update', e.target.value);
                this.content1 = e.target.value;
            }

        },
        check: function (e) {
            let win = this.window_portal;
            let t = win.$(e.target);
            if (t.val() && win.M.validate_field(t) && t.hasClass('valid')) {
                this.update(e);
                this.edit = false;
            }
        }
    }

});
let lpl = 0;
var app = new Vue({
    el: '#app',
    data: {
        paths: [],
        msgs: [],
        intype: 'file'
    },
    watch: {
        paths: function () {
            if (this.paths.length > lpl) {
                lpl = this.paths.length;
                setTimeout(function () {
                    M.FormSelect.init($('select'));
                }, 52);

            }
        }
    },
    methods: {
        addPath: function () {
            previous = createVector(0, 0);
            app.paths.push(new Path(app.paths.length + 1));
        },
        deletePaths: function () {
            app.paths = [];
            background(img);
            previous = createVector(0, 0);
        },
        build: function () {
            $('input.validate').each(function () {
                let el = $(this);
                M.validate_field(el);
                if (!el.val()) el.addClass('invalid').removeClass('valid');
            });
            input.removeClass('wrong');
            if (app.paths.length == 0 || app.paths.map(function (e) { return e.particles.length }).reduce(function (a, b) { return a + b }) == 0) return false;
            dirs = [];
            app.paths.forEach(function (e) {
                dirs.push({
                    path: doPath(e.particles.map(function (e) { return e.position })),
                    name: e.name,
                    type: e.type == "Program" ? 'p' : 'm',
                    desc: e.desc
                });
            });

            if (app.intype == 'file') if (input.elt.value && input.elt.value.indexOf(".ev3") > -1 && M.validate_field($('[minlength]'))) return;


            let formData = new FormData();
            app.intype == 'file' && formData.append("ev3", $("[type=file]")[0].files[0]);
            formData.append("directions", JSON.stringify(dirs));
            formData.append("export", app.intype);
            // formData.append("user", JSON.stringify(user));   // you can add also some json data to formData like e.g. user = {name:'john', age:34}

            let xhr = new XMLHttpRequest();
            xhr.open("POST", 'process.php');
            xhr.send(formData);

            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    let res = JSON.parse(xhr.responseText);
                    app.msgs = res.map(function (e) { e.text += "<span @click=\"window_portal.$($event.target).parent().remove()\">&times;</span>"; return e });
                    modal.open();
                    ga('send', 'event', {
                        eventCategory: 'Compile',
                        eventAction: 'click',
                        eventLabel: res.url
                    });
                }
            }

        }
    }
});
function $() {
    return cash.apply(this, arguments)
}
let modal = M.Modal.init($('.modal')[0]);

function doPath(vectors) {
    let ret = [];
    for (let i = 0, l = vectors.length; i < l; i++) {
        let vector = vectors[i];
        if (vectors[i + 1]) {
            let vector2 = vectors[i + 1];
            let angle = atan2(vector.y - vector2.y, vector.x - vector2.x);
            if (angle < 0) angle += TWO_PI;
            angle = (angle * 57.2958) - dir;
            targetDegrees = (2 * $('#wd').val() * PI) /
                $('#ker').val() * 20 / 12 * angle;
            dir = angle;
            ret.push({ turn: targetDegrees, spd: $('#tspd').val() });
            ret.push({ go: (dist(vector.x, vector.y, vector2.x, vector2.y) * (200 / 800)) / $('#ker').val(), spd: $('#spd').val() });

            console.log(ret);
        }

    }
    return ret;
}


function setup() {

    canvas = createCanvas(800, 400);
    canvas.parent('#can');
    img = loadImage("assets/field.jpg", function () {
        background(img);

    }); // Load the image
    current = createVector(0, 0);
    previous = createVector(0, 0);
    input = select('#file');
}



function draw() {

    // If it's time for a new point
    if (millis() > next && painting) {

        // Grab mouse position      
        current.x = mouseX;
        current.y = mouseY;

        // New particle's force is based on mouse movement

        // Add new particle
        if (!app.paths[app.paths.length - 1]) app.paths.push(new Path());
        app.paths[app.paths.length - 1].add(current);

        // Schedule next circle
        next = millis() + 500;

        // Store mouse values
        previous.x = current.x;
        previous.y = current.y;
    }
    strokeWeight(10);
    stroke(255, 100, 10);
    lines.forEach(function (w) {
        line(w[0].x, w[0].y, w[1].x, w[1].y);
    });
    // Draw all paths
    for (var i = 0; i < app.paths.length; i++) {
        app.paths[i].display();
    }

}

// Start it up
function mousePressed(e) {
    if (e.target.nodeName == "CANVAS") {

        next = 0;
        painting = true;
        previous.x = mouseX;
        previous.y = mouseY;
    }

}

// Stop
function mouseReleased() {
    painting = false;
    /* i++;
     if (i % 2 == 0) paths.push(new Path());
 */
}

// A Path is a list of particles
function Path(name = 1) {
    this.particles = [];
    this.name = 'Path_' + name;
    this.type = "Program";
    this.desc = '-';
    this.hl = false;
}

Path.prototype.add = function (position) {
    // Add a new particle with a position, force, and hue
    this.particles.push(new Particle(position));
}


// Display plath
Path.prototype.display = function () {
    // Loop through backwards
    for (var i = this.particles.length - 1; i >= 0; i--) {
        // If we shold remove it
        this.particles[i].display(this.particles[i + 1], this.hl);
    }

}

// Particles along the path
function Particle(position) {
    this.position = createVector(position.x, position.y);
}



// Draw particle and connect it with a line
// Draw a line to another
Particle.prototype.display = function (other, hl = false) {
    strokeWeight(10);
    if (hl) {
        stroke(50, 100, 255);

    } else {
        stroke(50, 255, 100);
    }

    // If we need to draw a line
    if (other) {
        line(this.position.x, this.position.y, other.position.x, other.position.y);
    }
    stroke(0, 0, 255);
    fill(0, 0, 255);
    ellipse(this.position.x, this.position.y, 8, 8);

}
M.FormSelect.init($('select'));