<?php

/**
 * Unzip the source_file in the destination dir
 *
 * @param   string      The path to the ZIP-file.
 * @param   string      The path where the zipfile should be unpacked, if false the directory of the zip-file is used
 * @param   boolean     Indicates if the files will be unpacked in a directory with the name of the zip-file (true) or not (false) (only if the destination directory is set to false!)
 * @param   boolean     Overwrite existing files (true) or not (false)
 *  
 * @return  boolean     Succesful or not
 */
function unzip($src_file, $dest_dir = false, $create_zip_name_dir = true, $overwrite = true)
{
    if ($zip = zip_open($src_file)) {
        if ($zip) {
            $splitter = ($create_zip_name_dir === true) ? "." : "/";
            // if ($dest_dir === false) $dest_dir = substr($src_file, 0, strrpos($src_file, $splitter)) . "/";
      
      // Create the directories to the destination dir if they don't already exist
            create_dirs($dest_dir . "/");

      // For every file in the zip-packet
            while ($zip_entry = zip_read($zip)) {
        // Now we're going to create the directories in the destination directories
        
        // If the file is not in the root dir
                $pos_last_slash = strrpos(zip_entry_name($zip_entry), "/");
                if ($pos_last_slash !== false) {
          // Create the directory where the zip-entry should be saved (with a "/" at the end)
                     //create_dirs($dest_dir . substr(zip_entry_name($zip_entry), 0, $pos_last_slash + 1));
                }

        // Open the entry
                if (zip_entry_open($zip, $zip_entry, "r")) {
          
          // The name of the file to save on the disk
                    $file_name = $dest_dir . '/' . basename(zip_entry_name($zip_entry));
                    
          // Check if the files should be overwritten or not
                    if ($overwrite === true || $overwrite === false && !is_file($file_name) && !is_dir($file_name)) {
            // Get the content of the zip entry
                        touch($file_name);
                        $fstream = zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

                        file_put_contents($file_name, $fstream);
            // Set the rights
                        chmod($file_name, 0777);
                    }
          
          // Close the entry
                    zip_entry_close($zip_entry);
                }
            }
      // Close the zip-file
            zip_close($zip);
        }
    } else {
        return false;
    }

    return true;
}
function addXML($xml, $el, $dom)
{
    $fd = $dom->createDocumentFragment();
    $fd->appendXML($xml);
    $el->parentNode->insertBefore($fd, $el);
}
/**
 * This function creates recursive directories if it doesn't already exist
 *
 * @param String  The path that should be created
 *  
 * @return  void
 */
function create_dirs($path)
{
    if (!is_dir($path)) {
        $directory_path = "";
        $directories = explode("/", $path);
        array_pop($directories);

        foreach ($directories as $directory) {
            $directory_path .= $directory . "/";
            if (!is_dir($directory_path)) {
                mkdir($directory_path);
                chmod($directory_path, 0777);
            }
        }
    }
}
function addContent($f, $of, $raw = false)
{
    global $tempDir;
    $file = $raw ? $f : "$tempDir/$f.ev3p";
    $con = file_get_contents($file);
    $c = empty($con) ? $of : $con . "\r\n" . $of;
    file_put_contents($file, $c);

}
function deleteDir($dir)
{
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? deleteDir("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}
$ret = [];
if (!isset($_POST['directions']) || empty($_POST['directions']) || !isset($_POST['export']) || empty($_POST['export']) || $_POST['export'] == 'file' && !isset($_FILES['ev3'])) {
    $ret[] = array("type" => "red", "text" => "Bad request!");
}
$hash = hash('sha1', date("YMDHhmMs"), false);
$target_dir = "user_files/";
$target_file = $target_dir . $hash . '-Paths.zip';
if ($_POST['export'] == 'empty') {
    $target_file = $target_dir . $hash . '-Path(s)InAKindaEmptyFile.ev3';
}
if ($_POST['export'] == 'file') {
    $target_file = $target_dir . $hash . '-' . basename($_FILES["ev3"]["name"]);
    $FileType = strtolower(pathinfo($_FILES["ev3"]["name"], PATHINFO_EXTENSION));
    if ($FileType != 'ev3') {
        $ret[] = array("type" => "red", "text" => "Bad filetype! Only .ev3 files are supported!");
    }
    if (!move_uploaded_file($_FILES["ev3"]["tmp_name"], $target_file)) {
        $ret[] = array("type" => "red", "text" => "Failed to upload file!");
    }
}
$tempDir = $target_file . "-TEMP";

if (file_exists("$tempDir")) {
    deleteDir("$tempDir");
}

if ($_POST['export'] == 'file') {
    if (!unzip("$target_file", "$tempDir")) {
        $ret[] = array("type" => "red", "text" => "UnZippin' failed! Maybe you didn't upload a real .ev3 file?");
    }
} elseif ($_POST['export'] == 'empty') {
    if (!unzip("empty.ev3", "$tempDir")) {
        $ret[] = array("type" => "red", "text" => "UnZippin' failed! Internal error! Sorry about that! Try again later!");
    }
} else mkdir("$tempDir");
if (!empty($ret)) {
    die(json_encode($ret));
}



$json = json_decode($_POST['directions'], true);

foreach ($json as $data) {
    $f = str_replace('/', '', $data['name']);
    $f = str_replace(' ', '', $f);
    $f = str_replace('.', '', $f);
    $f = str_replace('\\', '', $f);
    $rawF = $f;
    $i = 0;
    while (file_exists("$tempDir/$f.ev3p")) {
        $i++;
        $f = "$rawF ($i)";
    }
    touch("$tempDir/$f.ev3p");
    $is_mb = false;
    if ($data["type"] == "m" && !$_POST['export'] == 'ev3p') {
        $is_mb = true;
        $w = (count($data['path']) + 1) * 2;
        echo $w;
        addContent($f, str_replace('__WIRE', "w$w", file_get_contents("mbstart.xml")));
    } else {
        addContent($f, file_get_contents("start.xml"));
    }
    $prevBlockId = 1;
    $blockId = 2;
    $wireId = $is_mb ? $w : 3;
    $bound = $data["type"] == "m" ? 122 : 112;
    $outWire = "";
    $rot = 0;
    $lspd = 0;
    $rspd = 0;
    $i = 0;
    foreach ($data['path'] as $d) {
        $rep = file_get_contents("repeat.xml");
        if (isset($data[$i + 1])) {
            $w = $wireId + 2;
            $outWire = " Wire=\"$w\"";
        } else {
            $outWire = "";
        }
        if (isset($d['go'])) {
            $rot = floatval($d['go']) / 360;
            $lspd = $rspd = intval($d['spd']);
        } elseif (isset($d['turn'])) {
            $rot = floatval($d['turn']);
            $lspd = intval($d['spd']);
            $rspd = $lspd * -1;
        }
        if ($is_mb && $i == 0) {
            $rep = str_replace('<Wire Id="__wireID" Joints="N(__PrevblockID:SequenceOut) N(__blockID:SequenceIn)" />', '', $rep);
        }
        $rep = str_replace('__blockID', "n$blockId", $rep);
        $rep = str_replace('__wireID', "w$wireId", $rep);
        $rep = str_replace('__PrevblockID', "n$prevBlockId", $rep);
        $rep = str_replace('__outWire', $outWire, $rep);
        $rep = str_replace('__bound', $bound, $rep);
        $rep = str_replace('__LSPD', $lspd, $rep);
        $rep = str_replace('__RSPD', $rspd, $rep);
        $rep = str_replace('__ROTS', $rot, $rep);


        addContent($f, $rep);

        if ($i == 0) {
            $wireId = 3;
        }
        $prevBlockId = $blockId;
        $blockId += 2;
        $wireId += 2;
        $bound += 194;
        $i++;
    }
    if ($is_mb) addContent($f, '<Wire Id="w' . $w . '" Joints="N(n1:SequenceOut) N(n2:SequenceIn)" />');
    $str = $is_mb ? "mbend" : "end";
    addContent($f, file_get_contents("$str.xml"));
    if ($_POST['export'] == 'empty' || $_POST['export'] == 'file') {
        $dom = new DOMDocument;
        $dom->loadXML(file_get_contents("$tempDir/Project.lvprojx"));
        $el = $dom->getElementsByTagName('SourceFileReference')->item(0);
        $fn = "$f.ev3p";
        if ($is_mb) {
            touch("$tempDir/$fn.mbxml");
            file_put_contents("$tempDir/$fn.mbxml", str_replace('__DESC', htmlentities($data['desc']), file_get_contents("mb.xml")));
            $xml = '<SourceFileReference StoragePath="' . $fn . '" RelativeStoragePath="' . $fn . '" OverridingDocumentTypeIdentifier="X3VIDocument" DocumentTypeIdentifier="NationalInstruments.LabVIEW.VI.Modeling.VirtualInstrument" Name="' . str_replace(".", "\\.", $fn) . '" Bindings="Envoy,DefinitionReference,SourceFileReference,X3VIDocument" />' . "\r\n                " . '<DefinitionReference DocumentTypeIdentifier="NationalInstruments.ExternalFileSupport.Modeling.ExternalFileType" Name="' . str_replace(".", "\\.", $fn) . '\.mbxml" Bindings="Envoy,DefinitionReference,EmbeddedReference,ProjectItemDragDropDefaultService" />' . "\r\n                ";
            addXML($xml, $el, $dom);
            $xml = '    <Namespace Name="' . str_replace(".", "\\.", $fn) . '\.mbxml">
        <ExternalFile xmlns="http://www.ni.com/ExternalFile.xsd">
            <RelativeStoragePath>' . $fn . '.mbxml</RelativeStoragePath>
            <StoragePath />
        </ExternalFile>
    </Namespace>' . "\r\n                ";
            $fd = $dom->createDocumentFragment();
            $fd->appendXML($xml);
            $dom->getElementsByTagName('SourceFile')->item(0)->appendChild($fd);
        } else {
            $xml = '<SourceFileReference StoragePath="' . $fn . '" RelativeStoragePath="' . $fn . '" OverridingDocumentTypeIdentifier="X3VIDocument" DocumentTypeIdentifier="NationalInstruments.LabVIEW.VI.Modeling.VirtualInstrument" Name="' . str_replace(".", "\\.", $fn) . '" />' . "\r\n                ";
            addXML($xml, $el, $dom);
        }
        file_put_contents("$tempDir/Project.lvprojx", $dom->saveXML());
    }

}


function truepath($path)
{
    // whether $path is unix or not
    $unipath = strlen($path) == 0 || $path {
        0} != '/';
    // attempts to detect if path is relative in which case, add cwd
    if (strpos($path, ':') === false && $unipath)
        $path = getcwd() . DIRECTORY_SEPARATOR . $path;
    // resolve path parts (single dot, double dot and double delimiters)
    $path = str_replace(array('/', '\\'), DIRECTORY_SEPARATOR, $path);
    $parts = array_filter(explode(DIRECTORY_SEPARATOR, $path), 'strlen');
    $absolutes = array();
    foreach ($parts as $part) {
        if ('.' == $part) continue;
        if ('..' == $part) {
            array_pop($absolutes);
        } else {
            $absolutes[] = $part;
        }
    }
    $path = implode(DIRECTORY_SEPARATOR, $absolutes);
    // resolve any symlinks
    if (file_exists($path) && linkinfo($path) > 0) $path = readlink($path);
    // put initial separator that could have been lost
    $path = !$unipath ? '/' . $path : $path;
    return $path;
}

// Get real path for our folder
$rootPath = truepath($tempDir);

$zip = new ZipArchive;
if ($zip->open($target_file, (ZipArchive::CREATE | ZipArchive::OVERWRITE)) === true) {

    foreach (new DirectoryIterator($tempDir) as $fileInfo) {
        if (in_array($fileInfo->getFilename(), [".", ".."])) {
            continue;
        }
        $fileName = $fileInfo->getFilename();
        $zip->addFile($fileInfo->getPathname(), $fileName);
    }

    if (!$zip->close()) $ret[] = array("type" => "red", "text" => "Zippin failed contact the webadministrator!");
    else {
        $url = "dl.php?dl=" . str_replace($target_dir, '', $target_file);
        $ret[] = array("type" => "green", "text" => "Build successfull! Download <a href=\"$url\">here</a> the finished file!");

    }
}
deleteDir($tempDir);
echo json_encode($ret);