<?php
if (!isset($_GET['dl']) || empty($_GET['dl'])) die("Wrong parametrs");
$path = "user_files/" . str_replace('/', '', $_GET['dl']);
if (!file_exists($path) || is_dir($path)) die('WRONG PATH!');
$finfo = finfo_open(FILEINFO_MIME_TYPE);
header('Content-Type: ' . finfo_file($finfo, $path));

$finfo = finfo_open(FILEINFO_MIME_ENCODING);
header('Content-Transfer-Encoding: ' . finfo_file($finfo, $path));
$bname = explode('-', basename($path));
array_shift($bname);
$bname = join('-', $bname);
header('Content-disposition: attachment; filename="' . $bname . '"');
readfile($path); // do the double-download-dance (dirty but worky)
unlink($path);
