// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.
const { ipcRenderer } = require('electron')
const ifr = document.querySelector('iframe');
const fs = require('fs');

window.post = function (url, data, cb) {
    var xhr = new XMLHttpRequest(),
        fd = new FormData();

    Object.keys(data).forEach(e => {
        fd.append(e, data[e]);
    });
    xhr.open('POST', url, true);
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            cb(null, null, this.responseText);
        }
    };
    xhr.send(fd);
}


window.updateSrc = function () {
    let arr = [];
    arr.push(...fs.readdirSync(dir));
    post('http://localhost/roboktat/index.php',
        {
            formData: {
                update_local_files: JSON.stringify(arr)
            },
            timeout: 2500
        }, function (err, httpResponse, body) {
            iEval('location.reload();');
        });
}

post('http://localhost/roboktat/index.php', {
    formData: {
        usr: 'DESKTOP',
        psw: 'ezT1tkos',
        DESKTOP_GET_TOKEN: 0
    },
    timeout: 2500
}, function (err, httpResponse, body) {
    ipcRenderer.send("token", body);
});
ifr.src = "http://localhost/roboktat/index.php?desktop=[]";
var win = ifr.contentWindow;
window.iEval = function iEval(e) {
    win.postMessage(e, '*');
}
ipcRenderer.on('update', function (e, data) {
    ifr.src = "http://localhost/roboktat/index.php?desktop=" + data
});
window.addEventListener('message', function (e) {
    let data = JSON.parse(e.data);
    console.log(data)
    if (data.openInExp) {
        ipcRenderer.send('openInExp', data.data);
    } else if (data.push) {
        var formData = {
            fm_usr: 'desktop',
            fm_psw: 'yeah',
            token: token,
            file: fs.createReadStream(path.join(dir, d)),

        };
        post('http://localhost/roboktat/index.php?upload=1', formData,
            function cb(err, httpResponse, body) {
                if (err) {
                    return logEverywhere('upload failed:', err);
                }
                logEverywhere('Upload successful!  Server responded with:', body);
                updateSrc();
            }
        );
    }
});