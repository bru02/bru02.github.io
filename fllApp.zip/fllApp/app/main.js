const { app, BrowserWindow, Menu, ipcMain, shell } = require('electron')
// Module with utilities for working with file and directory paths.
const path = require('path')
// Module with utilities for URL resolution and parsing.
const url = require('url')
const fs = require('fs');
const { download } = require('electron-dl');
const docs = app.getPath('documents');
// const request = require('request');
var dir = path.join(docs, 'roboktat');
let token;

function linkCalled(url) {
  url = url.replace('roboktat://', '');
  logEverywhere('Opened with link:' + url);
}
// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow

// Deep linked url
let deeplinkingUrl

// Force Single Instance Application
const shouldQuit = app.makeSingleInstance((argv, workingDirectory) => {
  // Someone tried to run a second instance, we should focus our window.

  // Protocol handler for win32
  // argv: An array of the second instance’s (command line / deep linked) arguments
  if (process.platform == 'win32') {
    // Keep only command line / deep linked arguments
    deeplinkingUrl = argv.slice(1)
  }
  linkCalled(deeplinkingUrl)

  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore()
    mainWindow.focus()
  }
})
if (shouldQuit) {
  app.quit()
  return
}


ipcMain.on('token', function (e, r) {
  token = r;
});



function updateSrc() {
  mainWindow.webContents.executeJavaScript("window.updateSrc&&updateSrc();")
}
function createWindow() {
  // Create the browser window.
  mainWindow = new BrowserWindow({ width: 800, height: 600 })
  // and load the index.html of the app.
  mainWindow.loadURL(url.format({
    pathname: path.join('index.html'),
    protocol: 'file:',
    slashes: true
  }))
  mainWindow.maximize();

  // Protocol handler for win32
  if (process.platform == 'win32') {
    // Keep only command line / deep linked arguments
    deeplinkingUrl = process.argv.slice(1)
  }

  // Emitted when the window is closed.
  mainWindow.on('closed', function () {
    mainWindow = null
  })
  let m = Menu.buildFromTemplate([{
    label: 'dev', submenu: [
      { role: 'reload' },
      { role: 'forcereload' },
      { role: 'toggledevtools' },
      {
        label: 'Clear cache',
        accelerator: 'CmdOrCtrl+Shift+C',
        click() {
          mainWindow.webContents.session.clearCache(function () {
            mainWindow.webContents.executeJavaScript('location.reload()');

          })
        }
      },
      {
        label: 'Relaunch',
        accelerator: 'CmdOrCtrl+R',
        click() {
          app.relaunch({ args: process.argv.slice(1).concat(['--relaunch']) });
          app.exit(0);
        }
      },
      {
        label: 'Quit',
        accelerator: 'CmdOrCtrl+Q',
        click() {
          app.quit();
        }
      }
    ]
  }]);
  Menu.setApplicationMenu(m);
  updateSrc();
}
app.on('ready', createWindow)

if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, 0744);
}

ipcMain.on('openInExp', function (a, e) {
  logEverywhere(e);
  let fp = path.join(dir, e);
  if (!fs.existsSync()) {
    download(BrowserWindow.getFocusedWindow(), path.join('http://localhost/roboktat/data', e), { directory: dir })
      .then(shell.openItem(fp));
  } else {
    shell.openItem(fp);
  }
});

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.

// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On OS X it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  app.quit()
})

app.on('activate', function () {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) {
    createWindow()
  }
})

// Define custom protocol handler. Deep linking works on packaged versions of the application!
app.setAsDefaultProtocolClient('roboktat')

// Protocol handler for osx
app.on('open-url', function (event, url) {
  event.preventDefault()
  deeplinkingUrl = url
  linkCalled(deeplinkingUrl)
})

// Log both at dev console and at running node console instance
function logEverywhere(s) {
  console.log(s)
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.executeJavaScript(`console.log("${s}")`)
  }
}
