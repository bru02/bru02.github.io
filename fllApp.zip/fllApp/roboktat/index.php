<?php
session_cache_limiter('');
session_name('filemanager');
session_start();
   //Auth with login/password (set true/false to enable/disable it)
$use_auth = true;
   //Users: array('Username' => 'Password', 'Username2' => 'Password2', ...), Password has to encripted into 
$admins = array(
    "bence" => md5('a')
);

//Algorithm to check passwords
function passWordCheck($psw, $psw2)
{
    return md5($psw) == $psw2;
}

$site_title = "Roboktat";
$site_desc = "Jee.";
   //Show or hide files and folders that starts with a dot
$show_hidden_files = false;
   //Enable highlight.js (https://highlightjs.org/) on view's page
$use_highlightjs = true;
   //highlight.js style
$highlightjs_style = 'vs';
   //Enable ace.js (https://ace.c9.io/) on view's page
$edit_files = false;
   //Send files though mail
$send_mail = true;
   //Send files though mail
$from_name = "John Doe";
$from_email = "John@example.com";
      //Default timezone for date() and time() - http://php.net/manual/en/timezones.php
$default_timezone = 'Etc/UTC'; //UTC
   //Root path for file manager
$root_path = $_SERVER['DOCUMENT_ROOT'] . '/roboktat/data';  //'www.bru02.nhely.hu/';
   //Root url for links in file manager.Relative to $http_host. Variants: '', 'path/to/subfolder'
   //Will not working if $root_path will be outside of server document root
$root_url = 'http://bru02.nhely.hu/roboktat/data';
   //Server hostname. Can set manually if wrong
$http_host = $_SERVER['HTTP_HOST'];
   //input encoding for iconv
$iconv_input_encoding = 'UTF-8';
   //date() format for file modification date
$datetime_format = 'd.m.y H:i';
   //allowed upload file extensions
$upload_extensions = ''; //'gif,png,jpg'
   //show or hide the left side tree view
$show_tree_view = false;
   //Array of folders excluded from listing
$GLOBALS['exclude_folders'] = array();
if (isset($_FILES) && isset($_POST['token'])) {
    if (isset($_SESSION['desktop']) && $_SESSION['desktop']['token'] == $_POST['token'])
        $use_auth = false;
}
if (isset($_POST['DESKTOP_GET_TOKEN']) && isset($_POST['usr']) && isset($_POST['psw']) && $_POST['usr'] == 'DESKTOP' && $_POST['psw'] == 'ezT1tkos') {
    $token = md5(uniqid());
    $_SESSION['desktop'] = array(
        'token' => $token,
        'localFiles' => json_decode($_POST['DESKTOP_GET_TOKEN'], true)
    );
    echo $token;
    exit();
}

define('DESKTOP', isset($_SESSION['desktop']));

if (DESKTOP && isset($_POST['update_local_files'])) {
    $_SESSION['desktop']['localFiles'] = json_decode($_POST['update_local_files'], true);
    echo 'success';
    exit();
}


@set_time_limit(600);
date_default_timezone_set($default_timezone);
ini_set('default_charset', 'UTF-8');
if (version_compare(PHP_VERSION, '5.6.0', '<') && function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}
if (function_exists('mb_regex_encoding')) {
    mb_regex_encoding('UTF-8');
}

$is_https = isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1)
    || isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https';

   //clean $root_url
$root_url = fm_clean_path($root_url);
   //abs path for site
defined('FM_BASE_URL') || define('FM_BASE_URL', ($is_https ? 'https' : 'http') . '://' . $http_host);
defined('FM_SHOW_HIDDEN') || define('FM_SHOW_HIDDEN', $show_hidden_files);
defined('FM_ROOT_URL') || define('FM_ROOT_URL', $root_url);
defined('FM_TITLE') || define('FM_TITLE', $site_desc);
defined('FM_DESC') || define('FM_DESC', $site_title);

defined('FM_SELF_URL') || define('FM_SELF_URL', FM_BASE_URL . $_SERVER['PHP_SELF']);
defined('FM_PUBLIC_HTML') || define('FM_PUBLIC_HTML', $_SERVER['DOCUMENT_ROOT']);

     //logout
if (isset($_GET['logout'])) {
    unset($_SESSION['user']);
    fm_redirect(FM_SELF_URL);
}


   //Auth
if ($use_auth) {
    if (isset($_SESSION['user'])) {
        //Logged
    } elseif (isset($_POST['fm_usr'], $_POST['fm_pwd'])) {
        //Logging In
        if (isset($admins[$_POST['fm_usr']]) && passWordCheck($_POST['fm_pwd'], $admins[$_POST['fm_usr']])) {
            $_SESSION['user'] = $_POST['fm_usr'];
            fm_add_msg('You are logged in');
            //if ($_POST['fm_usr'] != 'desktop')
            fm_redirect(FM_SELF_URL . '?p=');

        } else {
            unset($_SESSION['user']);
            fm_add_msg('Wrong password', 'error');
            fm_redirect(FM_SELF_URL);
        }
    } else {
        //Form
        unset($_SESSION['user']);
        fm_show_header_login();
        fm_show_message();
        ?>
        <div class="container">
                <img src="src/cloud" class="responsive-img">
            <form action="" method="post">
            <div class="input-field">
                <input type="text" id="fm_usr" name="fm_usr" class="validate" value="" required>
                <label for="fm_usr">Username</label>
            </div>
            <div class="input-field">
                <input type="password" id="fm_pwd" name="fm_pwd" value="" class="validate" required>
                <label for="fm_pwd">Password</label>
                <span class="helper-text" data-error="Wrong password!"></span>

            </div>
                <button class="btn-small waves-effect waves-light" type="submit" name="action">Login
                &#xe163;
                </button>
            </form>
        </div>
        <?php
        fm_show_footer_login();
        exit;
    }
}

defined('FM_READONLY') || define('FM_READONLY', false);
//clean and check $root_path
$root_path = rtrim($root_path, '\\/');
$root_path = str_replace('\\', '/', $root_path);
if (!@is_dir($root_path)) {
    echo "<h1>Root path \"$root_path\" not found!</h1>";
    exit;
}
defined('FM_REAL_ROOT') || define('FM_REAL_ROOT', $root_path);
defined('FM_ROOT_PATH') || define('FM_ROOT_PATH', $root_path);

defined('FM_EXTENSION') || define('FM_EXTENSION', $upload_extensions);
define('FM_IS_WIN', DIRECTORY_SEPARATOR == '\\');

   //always use ?p=
if (!isset($_GET['p']) && empty($_FILES)) {
    fm_redirect(FM_SELF_URL . '?p=');
}
   //get path
$p = isset($_REQUEST['p']) ? $_REQUEST['p'] : '';
   //clean path
$p = fm_clean_path($p);
   //instead globals vars
define('FM_PATH', $p);
define('FM_USE_AUTH', $use_auth);
define('FM_EDIT_FILE', $edit_files);
defined('FM_ICONV_INPUT_ENC') || define('FM_ICONV_INPUT_ENC', $iconv_input_encoding);
defined('FM_USE_HIGHLIGHTJS') || define('FM_USE_HIGHLIGHTJS', $use_highlightjs);
defined('FM_HIGHLIGHTJS_STYLE') || define('FM_HIGHLIGHTJS_STYLE', $highlightjs_style);
defined('FM_DATETIME_FORMAT') || define('FM_DATETIME_FORMAT', $datetime_format);
unset($p, $use_auth, $iconv_input_encoding, $use_highlightjs, $highlightjs_style);
if (isset($_POST['table'])) {
    table($_POST['table']);
    exit();
}
/*************************** ACTIONS ***************************/

if (!FM_READONLY) {
            //AJAX Request
    if (isset($_POST['ajax'])) {

            //Send file to mail
        if (isset($_POST['mailto']) && isset($_POST['type']) && $_POST['type'] == "mail") {
            $filename = htmlentities($_POST['file']);
            $path = htmlentities($_POST['path']);
            $file = $path . $filename;
            echo $file . "\n";
            $content = @file_get_contents($file);
            echo $content . "\n";
            $content = chunk_split(base64_encode($content));
            $uid = md5(uniqid(time()));
            $name = basename($file);
            $mailto = htmlentities($_POST['mailto']);
            $subject = "$filename was sent to you!";
            $message = "Hello! $from_name has sent you $filename!";
                //header
            $header = "From: " . $from_name . " <" . $from_email . ">\r\n";
            $header .= "Reply-To: " . $from_email . "\r\n";
            $header .= "MIME-Version: 1.0\r\n";
            $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"\r\n\r\n";
                
                //message & attachment
            $nmessage = "--" . $uid . "\r\n";
            $nmessage .= "Content-type:text/plain; charset=iso-8859-1\r\n";
            $nmessage .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
            $nmessage .= $message . "\r\n\r\n";
            $nmessage .= "--" . $uid . "\r\n";
            $nmessage .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"\r\n";
            $nmessage .= "Content-Transfer-Encoding: base64\r\n";
            $nmessage .= "Content-Disposition: attachment; filename=\"" . $filename . "\"\r\n\r\n";
            $nmessage .= $content . "\r\n\r\n";
            $nmessage .= "--" . $uid . "--";

            if (mail($mailto, $subject, $nmessage, $header)) {
                echo "Mail sent successfully!"; //Or do something here
            } else {
                echo "Failed";
            }
        }
                //Download
        
            //backup files
        if (isset($_POST['type']) && $_POST['type'] == "push") {
            $file = $_POST['file'];
            $path = $_POST['path'];
            $summ = $_POST['summ'];
            $date = date("dmY-His");
            fm_mkdir(FM_ROOT_PATH . "/SAVE_SAVES/$date/");
            fm_rcopy($path . '/' . $file, FM_ROOT_PATH . "/SAVE_SAVES/$date/", true) or die("SAVE_SAVES FAILED!");
            $cont = json_decode(file_get_contents("contribute.json"), true);
            $cont[] = array(
                'who' => $_SESSION['user'],
                'what' => $file,
                'summary' => $summ,
                'backup' => "/SAVE_SAVES/$date/" . $file
            );
            file_put_contents("contribute.json", json_encode($cont));
            echo "Pushed $file to MAIN. Backup at SAVE_SAVES/$date/$file";
        }
        exit;
    }
    if (isset($_GET['dl'])) {
        $dl = $_GET['dl'];
        $dl = fm_clean_path($dl);
        $dl = str_replace('/', '', $dl);
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        if ($dl != '' && is_file($path . '/' . $dl)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($path . '/' . $dl) . '"');
            header('Content-Transfer-Encoding: binary');
            header('Connection: Keep-Alive');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
            header('Content-Length: ' . filesize($path . '/' . $dl));
            readfile($path . '/' . $dl);
            exit;
        } else {
            fm_add_msg('File not found', 'error');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
    }
        //Create folder
    if (isset($_GET['new']) && isset($_GET['type'])) {
        $new = strip_tags($_GET['new']);
        $type = $_GET['type'];
        $new = fm_clean_path($new);
        $new = str_replace('/', '', $new);
        if ($new != '' && $new != '..' && $new != '.') {
            $path = FM_ROOT_PATH;
            if (FM_PATH != '') {
                $path .= '/' . FM_PATH;
            }
            if ($_GET['type'] == "file") {
                if (!file_exists("$path/$new")) {

                    @fopen("$path/$new", 'w') or die('Cannot open file:  ' . $new);
                    fm_add_msg(sprintf('File <b>%s</b> created', fm_enc($new)));
                } else {
                    fm_add_msg(sprintf('File <b>%s</b> already exists', fm_enc($new)), 'alert');
                }
            } else {
                if (fm_mkdir("$path/$new", false) === true) {
                    fm_add_msg(sprintf('Folder <b>%s</b> created', $new));
                } elseif (fm_mkdir("$path/$new", false) === $path . '/' . $new) {
                    fm_add_msg(sprintf('Folder <b>%s</b> already exists', fm_enc($new)), 'alert');
                } else {
                    fm_add_msg(sprintf('Folder <b>%s</b> not created', fm_enc($new)), 'error');
                }
            }
        } else {
            fm_add_msg('Wrong folder name', 'error');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
        //Copy folder /file
    if (isset($_GET['copy'], $_GET['finish'])) {
                //from
        $copy = $_GET['copy'];
        $copy = fm_clean_path($copy);
                //empty path
        if ($copy == '') {
            fm_add_msg('Source path not defined', 'error');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
                //abs path from
        $from = FM_ROOT_PATH . '/' . $copy;
                //abs path to
        $dest = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $dest .= '/' . FM_PATH;
        }
        $dest .= '/' . basename($from);
                //move?
        $move = isset($_GET['move']);
                //copy/move
        if ($from != $dest) {
            $msg_from = trim(FM_PATH . '/' . basename($from), '/');
            if ($move) {
                $rename = fm_rename($from, $dest);
                if ($rename) {
                    fm_add_msg(sprintf('Moved from <b>%s</b> to <b>%s</b>', fm_enc($copy), fm_enc($msg_from)));
                } elseif ($rename === null) {
                    fm_add_msg('File or folder with this path already exists', 'alert');
                } else {
                    fm_add_msg(sprintf('Error while moving from <b>%s</b> to <b>%s</b>', fm_enc($copy), fm_enc($msg_from)), 'error');
                }
            } else {
                if (fm_rcopy($from, $dest)) {
                    fm_add_msg(sprintf('Copyied from <b>%s</b> to <b>%s</b>', fm_enc($copy), fm_enc($msg_from)));
                } else {
                    fm_add_msg(sprintf('Error while copying from <b>%s</b> to <b>%s</b>', fm_enc($copy), fm_enc($msg_from)), 'error');
                }
            }
        } else {
            fm_add_msg('Paths must be not equal', 'alert');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
        //Mass copy files/folders
    if (isset($_POST['file'], $_POST['copy_to'], $_POST['finish'])) {
                //from
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
                //to
        $copy_to_path = FM_ROOT_PATH;
        $copy_to = fm_clean_path($_POST['copy_to']);
        if ($copy_to != '') {
            $copy_to_path .= '/' . $copy_to;
        }
        if ($path == $copy_to_path) {
            fm_add_msg('Paths must be not equal', 'alert');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
        if (!is_dir($copy_to_path)) {
            if (!fm_mkdir($copy_to_path, true)) {
                fm_add_msg('Unable to create destination folder', 'error');
                fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
            }
        }
                //move?
        $move = isset($_POST['move']);
                //copy/move
        $errors = 0;
        $files = $_POST['file'];
        if (is_array($files) && count($files)) {
            foreach ($files as $f) {
                if ($f != '') {
                            //abs path from
                    $from = $path . '/' . $f;
                            //abs path to
                    $dest = $copy_to_path . '/' . $f;
                            //do
                    if ($move) {
                        $rename = fm_rename($from, $dest);
                        if ($rename === false) {
                            $errors++;
                        }
                    } else {
                        if (!fm_rcopy($from, $dest)) {
                            $errors++;
                        }
                    }
                }
            }
            if ($errors == 0) {
                $msg = $move ? 'Selected files and folders moved' : 'Selected files and folders copied';
                fm_add_msg($msg);
            } else {
                $msg = $move ? 'Error while moving items' : 'Error while copying items';
                fm_add_msg($msg, 'error');
            }
        } else {
            fm_add_msg('Nothing selected', 'alert');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
        //Rename
    if (isset($_GET['ren'], $_GET['to'])) {
                //old name
        $old = $_GET['ren'];
        $old = fm_clean_path($old);
        $old = str_replace('/', '', $old);
                //new name
        $new = $_GET['to'];
        $new = fm_clean_path($new);
        $new = str_replace('/', '', $new);
                //path
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
                //rename
        if ($old != '' && $new != '') {
            if (fm_rename($path . '/' . $old, $path . '/' . $new)) {
                fm_add_msg(sprintf('Renamed from <b>%s</b> to <b>%s</b>', fm_enc($old), fm_enc($new)));
            } else {
                fm_add_msg(sprintf('Error while renaming from <b>%s</b> to <b>%s</b>', fm_enc($old), fm_enc($new)), 'error');
            }
        } else {
            fm_add_msg('Names not set', 'error');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }

        //Upload
    if (!empty($_FILES)) {
        $f = $_FILES;
        $ck = false;

        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        $errors = 0;
        $uploads = 0;
        $total = count($f['file']['name']);
        $allowed = (FM_EXTENSION) ? explode(',', FM_EXTENSION) : false;
        $filename = $f['file']['name'];
        $tmp_name = $f['file']['tmp_name'];
        $isFileAllowed = ($allowed) ? in_array($ext, $allowed) : true;
        $name = $path . '/' . $f['file']['name'];
        $i = 0;
        $tempName = $f['file']['name'];
        $tempName = explode('.', $tempName);
        $ext = array_pop($tempName);
        $tempName = join('.', $tempName);
        while (file_exists($fullpath)) {
            fm_rdelete($fullpath);
        }
        if (empty($f['file']['error']) && !empty($tmp_name) && $tmp_name != 'none' && $isFileAllowed) {
            if (move_uploaded_file($tmp_name, $fullpath)) {

                die('Successfully uploaded');
            } else {
                die(sprintf('Error while uploading files. Uploaded files: %s', $uploads));
            }
        }
        exit();
    }
        //Mass deleting
    if (isset($_POST['group'], $_POST['delete'])) {
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        $errors = 0;
        $files = $_POST['file'];
        if (is_array($files) && count($files)) {
            foreach ($files as $f) {
                if ($f != '') {
                    $new_path = $path . '/' . $f;
                    if (!fm_rdelete($new_path)) {
                        $errors++;
                    }
                }
            }
            if ($errors == 0) {
                fm_add_msg('Selected files and folder deleted');
            } else {
                fm_add_msg('Error while deleting items', 'error');
            }
        } else {
            fm_add_msg('Nothing selected', 'alert');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
        //Pack files
    if (isset($_POST['group'], $_POST['zip'])) {
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        if (!class_exists('ZipArchive')) {
            fm_add_msg('Operations with archives are not available', 'error');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
        $files = $_POST['file'];
        if (!empty($files)) {
            chdir($path);
            if (count($files) == 1) {
                $one_file = reset($files);
                $one_file = basename($one_file);
                $zipname = $one_file . '_' . date('ymd_His') . '.zip';
            } else {
                $zipname = 'archive_' . date('ymd_His') . '.zip';
            }
            $zipper = new FM_Zipper();
            $res = $zipper->create($zipname, $files);
            if ($res) {
                fm_add_msg(sprintf('Archive <b>%s</b> created', fm_enc($zipname)));
            } else {
                fm_add_msg('Archive not created', 'error');
            }
        } else {
            fm_add_msg('Nothing selected', 'alert');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
        //Unpack
    if (isset($_GET['unzip'])) {
        $unzip = $_GET['unzip'];
        $unzip = fm_clean_path($unzip);
        $unzip = str_replace('/', '', $unzip);
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        if (!class_exists('ZipArchive')) {
            fm_add_msg('Operations with archives are not available', 'error');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
        if ($unzip != '' && is_file($path . '/' . $unzip)) {
            $zip_path = $path . '/' . $unzip;
                    //to folder
            $tofolder = '';
            if (isset($_GET['tofolder'])) {
                $tofolder = pathinfo($zip_path, PATHINFO_FILENAME);
                if (fm_mkdir($path . '/' . $tofolder, true)) {
                    $path .= '/' . $tofolder;
                }
            }
            $zipper = new FM_Zipper();
            $res = $zipper->unzip($zip_path, $path);
            if ($res) {
                fm_add_msg('Archive unpacked');
            } else {
                fm_add_msg('Archive not unpacked', 'error');
            }
        } else {
            fm_add_msg('File not found', 'error');
        }
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }

}
/*************************** /ACTIONS ***************************/
   //get current path
$path = FM_ROOT_PATH;
if (FM_PATH != '') {
    $path .= '/' . FM_PATH;
}
   //check path
if (!is_dir($path)) {
    fm_redirect(FM_SELF_URL . '?p=');
}

   //get parent folder
$parent = fm_get_parent_path(FM_PATH);
$objects = is_readable($path) ? scandir($path) : array();
$folders = array();
$files = array();
if (is_array($objects)) {
    foreach ($objects as $file) {
        if ($file == '.' || $file == '..' || in_array($file, $GLOBALS['exclude_folders'])) {
            continue;
        }
        if (!FM_SHOW_HIDDEN && substr($file, 0, 1) === '.') {
            continue;
        }
        $new_path = "$path/$file";
        if (is_file($new_path)) {
            $files[] = $file;
        } elseif (is_dir($new_path)) {
            $folders[] = $file;
        }
    }
}
if (!empty($files)) {
    natcasesort($files);
}
if (!empty($folders)) {
    natcasesort($folders);
}
   //upload form
if (isset($_GET['upload']) && !FM_READONLY) {
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path
    ?>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/min/dropzone.min.css" rel="stylesheet">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/min/dropzone.min.js"></script>
        <div class="path">
        <p><b>Uploading files</b></p>
        <p class="break-word">Destination folder: <?php echo fm_enc(fm_convert_win(FM_ROOT_PATH . '/' . FM_PATH)) ?></p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?p=' . fm_enc(FM_PATH) ?>" class="dropzone" id="fileuploader" enctype="multipart/form-data">
            <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
            <div class="fallback">
                <input name="file" type="file" multiple />
            </div>
        </form>
        </div>
<?php
fm_show_footer();
exit;
}

//ISSUES
if (isset($_GET['issues'])) {
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path
    $issues = json_decode(file_get_contents('issues.json'), true);
    function sortit($a, $b)
    {
        if ($a['closed'] === $b['closed']) {
            return 0;
        }
        return $a['closed'] > $b['closed'] ? -1 : 1;
    }
    uasort($issues, 'sortit');

    ?>
<div class="container">
<input type="text" id="search" onkeyup="search()" placeholder="Search for issues..">
<a class="btn-small green darken-1 waves-effect waves-green" href="?p=&newissue=1">New Issue</a>
<hr>
    <table class="table striped highlight responsive-table">
        <thead>
            <tr>
                <td>Name</td>
                <td>Type</td>
                <td>Created by</td>
                <td>Closed</td>
                <td>Link</td>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($issues as $issue) {
                ?>
                <tr>
                        <td><?php echo $iss['name']; ?></td>
                        <td><?php echo $iss['type']; ?></td>
                        <td><?php echo $iss['owner']; ?></td>
                        <td><?php echo $iss['closed']; ?></td>
                        <td><a href="?p=&viewissue=<?php echo $iss['id']; ?>">Open</a></td>
                </tr>
                    <?php

                }
                ?>
        </tbody>
    </table>
</div>
<script>
    function get(s,m){return m?document.querySelectorAll(s):document.querySelector(s);}
    const input = get("#search"),
    tr = get("#table tr",true);
function search() {
  var filter,  td, i;
  filter = input.value.toUpperCase();
  for (i = 0; i <tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter)> -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
<?php
fm_show_footer();
exit;
}

if (isset($_GET['newissue'])) {
    print_r($_POST);
    if (isset($_POST['newIssue']) && isset($_POST['name']) && isset($_POST['tags']) && isset($_POST['body']) && !empty($_POST['name']) && !empty($_POST['tags']) && !empty($_POST['body'])) {
        include "parsedown.php";
        $issues = json_decode(file_get_contents('issues.json'), true);
        $id = count($issues) + 1;
        $data = array(
            'id' => $id,
            'name' => htmlentities($_POST['name']),
            'tags' => explode(',', htmlentities($_POST['tags'])),
            'closed' => false,
            'owner' => $_SESSION['user'],
            'events' => array(
                array(
                    'id' => 1,
                    'type' => 'Comment',
                    'author' => $_SESSION['user'],
                    'body' => parseMD($_POST['body']),
                    'raw' => strip_unsafe($_POST['body']),
                    'title' => 'Initial Issue',
                    'reactions' => array(
                        'tu' => [], //Thumbs up
                        'td' => [], //Thumbs down
                        'hr' => [], //Hooray
                        'cd' => [], //Confused
                        'sm' => [], //Smile
                        'cs' => []  // Claps
                    )
                )
            ),
            'comments' => 1,
            'opened' => date("Y-m-d")
        );
        $issues[] = $data;
        file_put_contents('issues.json', json_encode($issues));
        fm_add_msg('Issue created!');
        fm_redirect(FM_SELF_URL . "?p=&viewissue=$id");
    }
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path


    ?>
    <!-- MARKDOWN EDITOR -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css">
<script src="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js"></script>
    <!-- INPUT TYPE TAGS -->
    <link rel="stylesheet" href="https://npmcdn.com/tags-input@1.1.1/tags-input.css">
<script src="https://npmcdn.com/tags-input@1.1.1/tags-input.js"></script>

<div class="container">
    <form src="" method="POST">
        <h1>New issue!</h1>
        <div class="input-field">
            <input type="text" id="name" name="name" class="validate" required>
            <label for="name">Name</label>
        </div>
        <div class="input-field">
            <input type="tags" id="type" name="tags" placeholder="Issue tags..">
        </div>
        <textarea name="body" placeholder=""></textarea>
<button type="submit" class="btn-small green darken-1 waves-effect waves-green" name="newIssue" value="1">Create</button>
</form>
</div>
<script>
    function get(s,m){return m?document.querySelectorAll(s):document.querySelector(s);}
[].forEach.call(get('input[type="tags"]',true), tagsInput);
var simplemde = new SimpleMDE({element:get('textarea')})

</script>
<?php
fm_show_footer();
exit;
}

function getCommentHTML($html, $title, $actions = '', $emoji = false, $id = 0, $raw = '')
{
    $emojies = array(
        'tu' => '👍', //Thumbs up
        'td' => '👎', //Thumbs down
        'hr' => '🎉', //Hooray
        'cd' => '😕', //Confused
        'sm' => '😃', //Smile
        'cs' => '👏'  // Claps
    );
    $titles = array(
        'tu' => '+1', //Thumbs up
        'td' => '-1', //Thumbs down
        'hr' => 'Hooray', //Hooray
        'cd' => 'Wtf?', //Confused
        'sm' => 'Cool', //Smile
        'cs' => 'Congrats'  // Claps        
    );
    $raw = str_replace("'", "\'", $raw);
    $ret = "
<div class=\"comment\" data-id=\"$id\" data-raw='$raw'>
        <div class=\"header\"><div class=\"actions\">$actions</div><h3>$title</h3></div>
    <div class=\"body\">";
    $ret .= $html;
    $ret .= "</div> ";
    if ($emoji) {
        $ret .= "<div class=\"footer\"><div class=\"actions\"><div class=\"emoji\"><a class=\"resp-trigger\" tabindex='-1' title='Add Reaction'>+😃</a><div class=\"resp-choose\">";
        foreach ($emojies as $key => $m) {
            $title = $titles[$key];
            $ret .= "<span data-emoji='$key' title='$title'>$m</span>";
        }
        $ret .= "</div></div></div>";
        $b = false;
        foreach ($emoji as $key => $a) {
            $m = count($a);
            if ($m > 0) {
                if (!$b) {
                    $ret .= "<div class='react-cont'>";
                    $b = true;
                }
                $e = $emojies[$key];

                if (in_array($_SESSION['user'], $a)) {
                    $p = " active";
                }
                $ret .= "<span class=\"emoji-counter$p\" data-emoji=\"$key\">$e $m</span>";
            }
        }
        if ($b) {
            $ret .= "</div>";
        }

        $ret .= "<h3>|</h3></div>";
    }

    $ret .= "</div>";
    return $ret;
}

if (isset($_GET['viewissue'])) {
    $id = intval($_GET['viewissue']);
    $issues = json_decode(file_get_contents('issues.json'), true);
    $issue = array_filter($issues, function ($item) use ($id) {
        if ($item['id'] == $id) {
            return true;
        }
        return false;
    });
    if (isset($issue[0])) $issue = $issue[0];
    else {
        fm_add_msg('Issue not found', 'alert');
        fm_redirect(FM_SELF_URL);
    }
    $pos = array_search($issue, $issues);
    if (isset($_POST['commentId']) && isset($_POST['reaction'])) {
        $n = $issues[$pos]['events'][intval($_POST['commentId'])]['reactions'][$_POST['reaction']];
        if (in_array($_SESSION['user'], $n)) {
            if (($key = array_search($_SESSION['user'], $n)) !== false) {
                unset($n[$key]);
            }
        } else {
            $n[] = $_SESSION['user'];
        }
        $issues[$pos]['events'][intval($_POST['commentId'])]['reactions'][$_POST['reaction']] = $n;
        file_put_contents('issues.json', json_encode($issues));
        fm_add_msg('Reaction added!');
    }
    if (isset($_POST['commentId']) && isset($_POST['body'])) {
        include "parsedown.php";
        $issues[$pos]['events'][intval($_POST['commentId'])]['raw'] = strip_unsafe($_POST['body']);
        $issues[$pos]['events'][intval($_POST['commentId'])]['body'] = parseMD($_POST['body']);
        file_put_contents('issues.json', json_encode($issues));
        fm_add_msg('Comment added!');
    }
    if (isset($_POST['newComment']) && isset($_POST['body'])) {
        include "parsedown.php";
        $issues[$pos]['events'][] = array(
            'id' => count($issues[$pos]['events']) + 1,
            'type' => 'Comment',
            'author' => $_SESSION['user'],
            'body' => parseMD($_POST['body']),
            'raw' => strip_unsafe($_POST['body']),
            'title' => "<b>" . $_SESSION['user'] . "</b> commented on #" . $issues[$pos]['id'],
            'reactions' => array(
                'tu' => [], //Thumbs up
                'td' => [], //Thumbs down
                'hr' => [], //Hooray
                'cd' => [], //Confused
                'sm' => [], //Smile
                'cs' => []  // Claps
            )
        );
        $issues[$pos]['comments']++;
        file_put_contents('issues.json', json_encode($issues));
        fm_add_msg('Comment added!');
    }
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path


    ?>
    <!--MARKDOWN EDITOR-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css">
    <script src="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js"> </script>
        <!--INPUT TYPE TAGS-->
        <link rel="stylesheet" href="https://npmcdn.com/tags-input@1.1.1/tags-input.css">
        <script src="https://npmcdn.com/tags-input@1.1.1/tags-input.js"> </script>
        <div id="addTag" class="modal">
        <div class="modal-content">
        <a href="#close" title="Close" class="close">X</a>
        <h2> Add tags</h2>
        <form action='' method='POST'>
        <p> Add tags :  </p>
        <input type='tags' name='newTags' value="<?php echo join($issue['tags']); ?>">
        <input type="submit" name="submit" class="group-btn btn waves-effect waves-light" value="Add tags">
        </form>
        </div>
        </div>
        <div class="container">
        <h1> <?php echo $issue['name']; ?></h1>
    <p><span class="tag green"><?php echo $issue['closed'] ? 'Closed' : '(!) Open'; ?></span> Opened by <b><?php echo $issue['owner'], '</b>, on ', $issue['opened'];
                                                                                                            ?> </p>
    <div class="line"></div>
    <?php
    $i = 0;
    foreach ($issue['events'] as $ev) {
        switch ($ev["type"]) {
            case 'comment':
                echo getCommentHTML($ev['body'], $ev['title'], $_SESSION['user'] == $ev['author'] ? '<a class="editBtn">&#xf14b; Edit Issue</a>' : '', $ev['reactions'], $i, $ev['raw']);
                break;
            default:
                break;
        }
        $i++;
    }
    ?>
    <form src="" method="POST">
        <textarea name="body" placeholder="" style="height:300px;"></textarea>
<button type="submit" class="btn-small green darken-1 waves-effect waves-green" name="newComment" value="1">Add comment</button>
</form>
</div>
<script>
    function get(s,m){return m?document.querySelectorAll(s):document.querySelector(s);}
[].forEach.call(get('input[type="tags"]',true), tagsInput);
var simplemde = new SimpleMDE({element:get('textarea')})
      
</script>
<?php
fm_show_footer();
exit;
}

if (!FM_READONLY) {
   //copy form POST
    if (isset($_POST['copy'])) {
        $copy_files = $_POST['file'];
        if (!is_array($copy_files) || empty($copy_files)) {
            fm_add_msg('Nothing selected', 'alert');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
        fm_show_header(); //HEADER
        fm_show_nav_path(FM_PATH); //current path
        ?>
        <div class="path">
        <p><b>Copying</b></p>
        <form action="" method="post">
            <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
            <input type="hidden" name="finish" value="1">
            <?php
            foreach ($copy_files as $cf) {
                echo '<input type="hidden" name="file[]" value="' . fm_enc($cf) . '">' . PHP_EOL;
            }
            ?>
            <p class="break-word">Files: <b><?php echo implode('</b>, <b>', $copy_files) ?></b></p>
            <p class="break-word">Source folder: <?php echo fm_enc(fm_convert_win(FM_ROOT_PATH . '/' . FM_PATH)) ?><br>
                <label for="inp_copy_to">Destination folder:</label>
                <?php echo FM_ROOT_PATH ?>/<input type="text" name="copy_to" id="inp_copy_to" value="<?php echo fm_enc(FM_PATH) ?>">
            </p>
            <p><label><input type="checkbox" name="move" value="1" class="filled-in"> <span>Move</span></label></p>
            <p>
                <button type="submit" class="btn">&#xf058; Copy </button> &nbsp;
                <b><a href="?p=<?php echo urlencode(FM_PATH); ?>">&#xf057; Cancel</a></b>
            </p>
        </form>
        </div>
    <?php
    fm_show_footer();
    exit;
}
   //copy form
if (isset($_GET['copy']) && !isset($_GET['finish'])) {
    $copy = $_GET['copy'];
    $copy = fm_clean_path($copy);
    if ($copy == '' || !file_exists(FM_ROOT_PATH . '/' . $copy)) {
        fm_add_msg('File not found', 'error');
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path
    ?>
        <div class="path">
        <p><b>Copying</b></p>
        <p class="break-word">
            Source path: <?php echo fm_enc(fm_convert_win(FM_ROOT_PATH . '/' . $copy)) ?><br>
            Destination folder: <?php echo fm_enc(fm_convert_win(FM_ROOT_PATH . '/' . FM_PATH)) ?>
        </p>
        <p>
            <b><a href="?p=<?php echo urlencode(FM_PATH); ?>&amp;copy=<?php echo urlencode($copy) ?>&amp;finish=1">&#xf058; Copy</a></b> &nbsp;
            <b><a href="?p=<?php echo urlencode(FM_PATH); ?>&amp;copy=<?php echo urlencode($copy) ?>&amp;finish=1&amp;move=1">&#xf058; Move</a></b> &nbsp;
            <b><a href="?p=<?php echo urlencode(FM_PATH); ?>">&#xf057; Cancel</a></b>
        </p>
        <p><i>Select folder</i></p>
        <ul class="folders break-word">
            <?php
            if ($parent !== false) {
                ?>
            <li><a href="?p=<?php echo urlencode($parent) ?>&amp;copy=<?php echo urlencode($copy); ?>">&#xf137; ..</a></li>
            <?php

        }
        foreach ($folders as $f) {
            ?>
            <li><a href="?p=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')) ?>&amp;copy=<?php echo urlencode($copy); ?>"><i class="fi-folder"></i> <?php echo fm_convert_win($f) ?></a></li>
            <?php

        }
        ?>
        </ul>
        </div>
        <?php
        fm_show_footer();
        exit;
    }
   //file editor
    if (isset($_GET['edit'])) {
        $file = $_GET['edit'];
        $file = fm_clean_path($file);
        $file = str_replace('/', '', $file);
        if ($file == '' || !is_file($path . '/' . $file)) {
            fm_add_msg('File not found', 'error');
            fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
        }
        $file_path = $path . '/' . $file;
        $file_url = getFileURL($file_path);
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        $mime_type = fm_get_mime_type($file_path);
        $filesize = filesize($file_path);
        $is_text = false;
        $content = ''; //for text
        if (in_array($ext, fm_get_text_exts()) || substr($mime_type, 0, 4) == 'text' || in_array($mime_type, fm_get_text_mimes())) {
            $is_text = true;
            $content = file_get_contents($file_path);
        }
        fm_show_header(); //HEADER
        $r = "<li><a title=\"Cancel\" href=\"?p=" . urlencode(trim(FM_PATH)) . "&amp;view=" . urlencode($file) . "\">&#xf122; Cancel</a></li>" . ($is_text ? "<li><a href=\"#\" id=\"Save\" onclick=\"fm.saveEdit();return false;\">&#xf0c7; Save</a></li>" : '');
        fm_show_nav_path(FM_PATH, $r); //current path
         
        //Save File
        if (isset($_POST['savedata'])) {
            echo $file_path;
            $writedata = $_POST['savedata'];
            $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
            $fp = fopen($file_path, 'w');
            fputs($fp, $_POST['savedata']);
            fclose($fp);
            fm_add_msg('File Saved Successfully', 'alert');
        }

        ?>
        <div class="path">

        <?php
        if ($is_text) {
            echo '<div id="editor" contenteditable="true">' . htmlspecialchars($content) . '</div>';
            ?>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.9/ace.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.3.3/ext-modelist.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.3.3/ext-language_tools.js"></script>

            
            <script>
                ace.require("ace/ext/language_tools");

                var editor = ace.edit("editor");
                var filename = "<?php echo $file; ?>";
                var modelist = ace.require("ace/ext/modelist");
                var mode =  modelist.getModeForPath(filename).mode;
                editor.getSession().setMode(mode);
                editor.commands.addCommand({
                    name: 'saveFile',
                    bindKey: {
                    win: 'Ctrl-S',
                    mac: 'Command-S',
                    sender: 'editor|cli'
                    },
                    exec: function(env, args, request) {
                        fm.saveEdit();
                    }
                });
                editor.setOptions({
                    enableBasicAutocompletion: true,
                    enableSnippets: true,
                    enableLiveAutocompletion: false
                });
                </script>
                <?php

            } else {
                fm_add_msg('FILE EXTENSION HAS NO SUPPORT', 'error');
            }
            ?>
        </div>
    <?php
    fm_show_footer();
    exit;
}
}
//file viewer
if (isset($_GET['view'])) {
    $file = $_GET['view'];
    $file = fm_clean_path($file);
    $file = str_replace('/', '', $file);
    if ($file == '' || !is_file("$path/$file")) {
        fm_add_msg('File not found', 'error');
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }
    fm_show_header(); //HEADER
    fm_show_nav_path(FM_PATH); //current path
    $file_path = "$path/$file";
    $file_url = getFileURL($file_path);
    $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $mime_type = fm_get_mime_type($file_path);
    $filesize = filesize($file_path);
    $view_title = 'File';
    if ($ext == 'ev3') {
        $view_title = 'EV3 Project';
    }
    ?>
    <div class="path">
    <p class="break-word"><b><?php echo $view_title ?> "<?php echo fm_enc(fm_convert_win($file)) ?>"</b></p>
    <p class="break-word">
        Full path: <?php echo fm_enc(fm_convert_win($file_path)) ?><br>
        File size: <?php echo fm_get_filesize($filesize) ?> <?php echo ($filesize >= 1000) ? sprintf('(%s bytes)', $filesize) : ''; ?><br>
        MIME-type: <?php echo $mime_type ?><br>      
    </p>
    <p>
        <b><a href="?p=<?php echo urlencode(FM_PATH) ?>&amp;dl=<?php echo urlencode($file); ?>">&#xf0ed; Download</a></b> &nbsp;
<b><?php if (!DESKTOP) : ?><a href="roboktat://<?php echo fm_enc(str_replace(FM_ROOT_PATH, '', $file_path)) ?>" target="_blank">&#xf14c; Edit locally</a>

<?php if (@in_array($file, $_SESSION['desktop']['localFiles'])) : ?>
<b><a href='#push' data="<?php echo fm_enc($file) ?>" onclick="fm.push(<?php echo $path, ',', $file; ?>,function(){window.parent.postMessage(JSON.stringify({push:1,data:that.getAttribute('data')}),'*')});">Push to main</a></b>

<?php endif; ?>
<?php else : ?><a href="" data="<?php echo fm_enc(str_replace(FM_ROOT_PATH, '', $file_path)) ?>" onclick="var that=this;window.parent.postMessage(JSON.stringify({openInExp:1,data:that.getAttribute('data')}),'*');return false" target="_blank">&#xf14c; Open in explorer</a><?php endif; ?></b> &nbsp;

        <?php

        if ($send_mail) {
            ?>
        <b><a href="#" onclick="fm.mailFile('<?php echo urlencode(trim($path)); ?>','<?php echo urlencode($file) ?>');return false;">&#xf14b; Mail</a></b> &nbsp;
        <?php 
    } ?>
        <b><a href="?p=<?php echo urlencode(FM_PATH); ?>">&#xf137; Back</a></b>
    </p>

    </div>
<?php
fm_show_footer();
exit;
}
   //--- FILEMANAGER MAIN

       //get parent folder

fm_show_header(); //HEADER
fm_show_nav_path(FM_PATH, ''); //current path
   //messages
fm_show_message();
echo "<main>\n";
table($path);
?>
</main>
   <ul id="context-menu" class="dropdown-content context-menu">
    <ul class="context-menu__items">
    </ul>
</ul>
<?php
fm_show_footer();

   //--- END
   //Functions
function table($path)
{
    $parent = fm_get_parent_path(FM_PATH);
    $objects = is_readable($path) ? scandir($path) : array();
    $folders = array();
    $files = array();

    if (is_array($objects)) {
        foreach ($objects as $file) {
            if ($file == '.' || $file == '..' || in_array($file, $GLOBALS['exclude_folders'])) {
                continue;
            }
            if (!FM_SHOW_HIDDEN && substr($file, 0, 1) === '.') {
                continue;
            }
            $new_path = "$path/$file";
            if (is_file($new_path)) {
                $files[] = $file;
            } elseif (is_dir($new_path)) {
                $folders[] = $file;
            }
        }
    }
    $num_files = count($files);
    $num_folders = count($folders);
    $all_files_size = 0;
    if (!empty($files)) {
        natcasesort($files);
    }
    if (!empty($folders)) {
        natcasesort($folders);
    }
    ?>

<form action="" method="post">
   <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
   <input type="hidden" name="group" value="1">


   <table class="table striped highlight responsive-table" id="main-table">
   <?php

    ?>
        <thead>
            <tr>
                <?php if (!FM_READONLY) : ?>
                <th><label><input type="checkbox" id="topCheckbox" title="Invert selection" onclick="fm.changeCheckboxes(fm.checkboxes,this.checked)" class="filled-in"><span></span></label></th>
                <?php endif; ?>
                <th>Name</th>
                <th>Size</th>
                <th>Modified</th>
                <th>Actions</th>
            </tr>
        </thead>
        <?php
            //link to parent folder
        if ($parent !== false) {
            ?>
        <tr class="context">
            <?php if (!FM_READONLY) : ?>
            <td></td>
            <?php endif; ?>
            <td colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>"><a href="?p=<?php echo urlencode($parent) ?>">&#xf137; ..</a></td>

        </tr>
        <?php

    }
    foreach ($folders as $f) {
        $is_link = is_link($path . '/' . $f);
        $modif = date(FM_DATETIME_FORMAT, filemtime($path . '/' . $f));
        $perms = substr(decoct(fileperms($path . '/' . $f)), -4);
        if (function_exists('posix_getpwuid') && function_exists('posix_getgrgid')) {
            $owner = posix_getpwuid(fileowner($path . '/' . $f));
            $group = posix_getgrgid(filegroup($path . '/' . $f));
        } else {
            $owner = array('name' => '?');
            $group = array('name' => '?');
        }
        ?>
        <tr class="context">

            <?php if (!FM_READONLY) : ?>
            <td><label><input type="checkbox" name="file[]" value="<?php echo fm_enc($f) ?>" class="filled-in"><span></span></label></td>
            <?php endif; ?>
            <td>
                <div class="filename"><a href="?p=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')); ?>"><i class="fi-folder"></i> <?php echo fm_convert_win($f) ?></a><?php echo ($is_link ? ' &rarr; <i>' . readlink($path . '/' . $f) . '</i>' : '') ?></div>
            </td>
            <td>Folder</td>
            <td><?php echo $modif ?></td>
        </tr>

      <?php
        flush();

    }
    foreach ($files as $f) {
        $is_link = is_link($path . '/' . $f);
        $img = $is_link ? 'note' : fm_get_file_icon_class($f);
        $modif = date(FM_DATETIME_FORMAT, filemtime($path . '/' . $f));
        $filesize_raw = filesize($path . '/' . $f);
        $filesize = fm_get_filesize($filesize_raw);
        $filelink = '?p=' . urlencode(FM_PATH) . '&amp;view=' . urlencode($f);
        $all_files_size += $filesize_raw;
        $perms = substr(decoct(fileperms($path . '/' . $f)), -4);
        if (function_exists('posix_getpwuid') && function_exists('posix_getgrgid')) {
            $owner = posix_getpwuid(fileowner($path . '/' . $f));
            $group = posix_getgrgid(filegroup($path . '/' . $f));
        } else {
            $owner = array('name' => '?');
            $group = array('name' => '?');
        }
        $ext = strtolower(pathinfo($path . '/' . $f, PATHINFO_EXTENSION));


        ?>
      <tr class='context'>
         <?php if (!FM_READONLY) : ?>
         <td><label><input type="checkbox" name="file[]" value="<?php echo fm_enc($f) ?>" class="filled-in"><span></span></label></td>
         <?php endif; ?>
         <td>
            <div class="filename">
			<a href="<?php echo $filelink ?>" title="File info"><i class="<?php echo $img ?>"></i> <?php echo fm_convert_win($f) ?></a><?php echo ($is_link ? ' &rarr; <i>' . readlink($path . '/' . $f) . '</i>' : '') ?>
			
			</div>
         </td>
         <td><span title="<?php printf('%s bytes', $filesize_raw) ?>"><?php echo $filesize ?></span></td>
         <td><?php echo $modif ?></td> 
      </tr>
      <?php
        flush();
    }


    if (empty($folders) && empty($files)) {
        ?>
      <tr>
         <?php if (!FM_READONLY) : ?>
         <td></td>
         <?php endif; ?>
         <td colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>"><em><?php echo 'Folder is empty' ?></em></td>
      </tr>
      <?php

    } else {
        ?>
      <tr>
         <?php if (!FM_READONLY) : ?>
         <td class="gray"></td>
         <?php endif; ?>
         <td class="gray" colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>">
            Full size: <span title="<?php printf('%s bytes', $all_files_size) ?>"><?php echo fm_get_filesize($all_files_size) ?></span>,
            files: <?php echo $num_files ?>,
            folders: <?php echo $num_folders ?>
         </td>
      </tr>
      <?php

    }
    ?>
   </table>
   <?php if (!FM_READONLY) : ?>
   <p class="path footer-links"><a href="#/select-all" class="group-btn" onclick="fm.selectAll();return false;">&#xf14a; Select all</a> &nbsp;
      <a href="#/unselect-all" class="group-btn" onclick="fm.unselectAll();return false;">&#xf2d3; Unselect all</a> &nbsp;
      <a href="#/invert-all" class="group-btn" onclick="fm.invertAll();return false;">&#xf00b; Invert selection</a> &nbsp;
      <input type="submit" class="group-btn" name="copy" value="&#xf0c5; Copy">
   </p>
   <?php endif; ?>
</table>

   </form>
<?php 
}
/**
 * Delete  file or folder (recursively)
 * @param string $path
 * @return bool
 */
function fm_rdelete($path)
{
    if (is_link($path) || is_file($path)) {
        return unlink($path);
    } elseif (is_dir($path)) {
        $objects = scandir($path);
        $ok = true;
        if (is_array($objects)) {
            foreach ($objects as $file) {
                if ($file != '.' && $file != '..') {
                    if (!fm_rdelete($path . '/' . $file)) {
                        $ok = false;
                    }
                }
            }
        }
        return ($ok) ? rmdir($path) : false;
    }
    return false;
}
/**
 * Recursive chmod
 * @param string $path
 * @param int $filemode
 * @param int $dirmode
 * @return bool
 * @todo Will use in mass chmod
 */
function fm_rchmod($path, $filemode, $dirmode)
{
    if (is_dir($path)) {
        if (!chmod($path, $dirmode)) {
            return false;
        }
        $objects = scandir($path);
        if (is_array($objects)) {
            foreach ($objects as $file) {
                if ($file != '.' && $file != '..') {
                    if (!fm_rchmod($path . '/' . $file, $filemode, $dirmode)) {
                        return false;
                    }
                }
            }
        }
        return true;
    } elseif (is_link($path)) {
        return true;
    } elseif (is_file($path)) {
        return chmod($path, $filemode);
    }
    return false;
}
/**
 * Safely rename
 * @param string $old
 * @param string $new
 * @return bool|null
 */
function fm_rename($old, $new)
{
    return (!file_exists($new) && file_exists($old)) ? rename($old, $new) : null;
}
/**
 * Copy file or folder (recursively).
 * @param string $path
 * @param string $dest
 * @param bool $upd Update files
 * @param bool $force Create folder with same names instead file
 * @return bool
 */
function fm_rcopy($path, $dest, $upd = true, $force = true)
{
    if (is_dir($path)) {
        if (!fm_rmkdir($dest, $force)) {
            return false;
        }
        $objects = scandir($path);
        $ok = true;
        if (is_array($objects)) {
            foreach ($objects as $file) {
                if ($file != '.' && $file != '..') {
                    if (!fm_rcopy($path . '/' . $file, $dest . '/' . $file)) {
                        $ok = false;
                    }
                }
            }
        }
        return $ok;
    } elseif (is_file($path)) {
        return fm_copy($path, $dest, $upd);
    }
    return false;
}
/**
 * Safely create folder
 * @param string $dir
 * @param bool $force
 * @return bool
 */
function fm_mkdir($dir, $force)
{
    if (file_exists($dir)) {
        if (is_dir($dir)) {
            return $dir;
        } elseif (!$force) {
            return false;
        }
        unlink($dir);
    }
    return mkdir($dir, 0777, true);
}
/**
 * Safely copy file
 * @param string $f1
 * @param string $f2
 * @param bool $upd
 * @return bool
 */
function fm_copy($f1, $f2, $upd)
{
    $time1 = filemtime($f1);
    if (file_exists($f2)) {
        $time2 = filemtime($f2);
        if ($time2 >= $time1 && $upd) {
            return false;
        }
    }
    $ok = copy($f1, $f2);
    if ($ok) {
        touch($f2, $time1);
    }
    return $ok;
}
/**
 * Get mime type
 * @param string $file_path
 * @return mixed|string
 */
function fm_get_mime_type($file_path)
{
    $mime_types = array(
        'json' => 'application/json',
    );
    $ext = explode('.', $file_path);
    $ext = strtolower(array_pop($ext));
    if (isset($mime_types[$ext])) {
        return $mime_types[$ext];
    } else return '--';
}
/**
 * HTTP Redirect
 * @param string $url
 * @param int $code
 */
function fm_redirect($url, $code = 302)
{
    header('Location: ' . $url, true, $code);
    exit;
}

/**
 * Clean path
 * @param string $path
 * @return string
 */
function fm_clean_path($path)
{
    $path = trim($path);
    $path = trim($path, '\\/');
    $path = str_replace(array('../', '..\\'), '', $path);
    if ($path == '..') {
        $path = '';
    }
    $path = str_replace('\\', '/', $path);

    return $path;
}
/**
 * Get parent path
 * @param string $path
 * @return bool|string
 */
function fm_get_parent_path($path)
{
    $path = fm_clean_path($path);
    if ($path != '') {
        $array = explode('/', $path);
        if (count($array) > 1) {
            $array = array_slice($array, 0, -1);
            return implode('/', $array);
        }
        return '';
    }
    return false;
}
/**
 * Get nice filesize
 * @param int $size
 * @return string
 */
function fm_get_filesize($size)
{
    if ($size < 1000) {
        return sprintf('%s B', $size);
    } elseif (($size / 1024) < 1000) {
        return sprintf('%s KiB', round(($size / 1024), 2));
    } elseif (($size / 1024 / 1024) < 1000) {
        return sprintf('%s MiB', round(($size / 1024 / 1024), 2));
    } elseif (($size / 1024 / 1024 / 1024) < 1000) {
        return sprintf('%s GiB', round(($size / 1024 / 1024 / 1024), 2));
    } else {
        return sprintf('%s TiB', round(($size / 1024 / 1024 / 1024 / 1024), 2));
    }
}
/**
 * Get info about zip archive
 * @param string $path
 * @return array|bool
 */
function fm_get_zif_info($path)
{
    if (function_exists('zip_open')) {
        $arch = zip_open($path);
        if ($arch) {
            $filenames = array();
            while ($zip_entry = zip_read($arch)) {
                $zip_name = zip_entry_name($zip_entry);
                $zip_folder = substr($zip_name, -1) == '/';
                $filenames[] = array(
                    'name' => $zip_name,
                    'filesize' => zip_entry_filesize($zip_entry),
                    'compressed_size' => zip_entry_compressedsize($zip_entry),
                    'folder' => $zip_folder
                       //'compression_method' => zip_entry_compressionmethod($zip_entry),
                );
            }
            zip_close($arch);
            return $filenames;
        }
    }
    return false;
}
/**
 * Encode html entities
 * @param string $text
 * @return string
 */
function fm_enc($text)
{
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}
/**
 * This function scans the files folder recursively, and builds a large array
 * @param string $dir
 * @return json
 */
function scan($dir)
{
    $files = array();
    $_dir = $dir == "" ? '.' : $dir;
    $dir = FM_ROOT_PATH . (empty($dir) ? '' : "/$dir");
       //Is there actually such a folder/file?
    if (file_exists($dir)) {
        $p = scandir($dir);
        foreach ($p as $f) {
            if (!$f || $f[0] == '.') {
                continue; //Ignore hidden files
            }
            if (is_dir($dir . '/' . $f)) {
                   //The path is a folder
                $files[] = array(
                    "name" => $f,
                    "type" => "folder",
                    "path" => $_dir . '/' . $f,
                    "items" => scan(str_replace(FM_ROOT_PATH, '', $dir) . '/' . $f), //Recursively get the contents of the folder
                );
            } else {
                   //It is a file
                $files[] = array(
                    "name" => $f,
                    "type" => "file",
                    "path" => $_dir,
                    "icon" => fm_get_file_icon_class($f),
                    "size" => filesize($dir . '/' . $f) //Gets the size of this file
                );
            }
        }
    }
    return $files;
}
/**
 * Scan directory and return tree view
 * @param string $directory
 * @param boolean $first_call
 */
function php_file_tree_dir($directory)
{
    $php_file_tree = "";
   	//Get and sort directories/files
    $file = scandir($directory);
    natcasesort($file);
   	//Make directories first
    $files = $dirs = array();
    foreach ($file as $this_file) {
        if (is_dir("$directory/$this_file")) {
            if (!in_array($this_file, $GLOBALS['exclude_folders'])) {
                $dirs[] = $this_file;
            }
        } else {
            $files[] = $this_file;
        }
    }
    $file = array_merge($dirs, $files);
    if (count($file) > 0) {
        foreach ($file as $this_file) {
            if ($this_file != "." && $this_file != "..") {
                if (is_dir("$directory/$this_file")) {
                       //Directory

                    $path = str_replace(FM_ROOT_PATH, "", "$directory/$this_file");
                    $php_file_tree .= "";
                    $php_file_tree .= php_file_tree_dir("$directory/$this_file");
                    $php_file_tree .= "";
                } else {
   					//File
                    $path = str_replace(FM_ROOT_PATH, "", $directory);
                      //$path = substr_count("/",$path)==1 ? '' : $path;
                    $link = "?p=$path&view=" . urlencode($this_file);
                    $php_file_tree .= "<li><a href=\"$link\"> <i class=\"$ext\"></i>" . htmlspecialchars($this_file) . "</a></li>";
                }
            }
        }
        $php_file_tree .= "</ul>";
    }
    return $php_file_tree;
}

/**
 * Save message in session
 * @param string $msg
 * @param string $status
 */
function fm_add_msg($msg, $status = 'ok')
{
    $_SESSION['message'][] = array($msg, $status);
}
/**
 * Check if string is in UTF-8
 * @param string $string
 * @return int
 */
function fm_is_utf8($string)
{
    return preg_match('//u', $string);
}
/**
 * Convert file name to UTF-8 in Windows
 * @param string $filename
 * @return string
 */
function fm_convert_win($filename)
{
    if (FM_IS_WIN && function_exists('iconv')) {
        $filename = iconv(FM_ICONV_INPUT_ENC, 'UTF-8//IGNORE', $filename);
    }
    return $filename;
}
/**
 * Get CSS classname for file
 * @param string $path
 * @return string
 */
function fm_get_file_icon_class($path)
{
       //get extension
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    switch ($ext) {
        case 'ico':
        case 'gif':
        case 'jpg':
        case 'jpeg':
        case 'jpc':
        case 'jp2':
        case 'jpx':
        case 'xbm':
        case 'wbmp':
        case 'png':
        case 'bmp':
        case 'tif':
        case 'tiff':
        case 'svg':
            $img = 'photo';
            break;
        case 'passwd':
        case 'ftpquota':
        case 'sql':
        case 'js':
        case 'json':
        case 'sh':
        case 'config':
        case 'twig':
        case 'tpl':
        case 'md':
        case 'gitignore':
        case 'c':
        case 'cpp':
        case 'cs':
        case 'py':
        case 'map':
        case 'lock':
        case 'dtd':
            $img = 'file_code';
            break;
        case 'txt':
        case 'ini':
        case 'conf':
        case 'log':
        case 'htaccess':
        case 'csv':
            $img = 'textfile';
            break;
        case 'css':
        case 'less':
        case 'sass':
        case 'scss':
            $img = 'css';
            break;
        case 'zip':
        case 'rar':
        case 'gz':
        case 'tar':
        case '7z':
            $img = 'zip';
            break;
        case 'php':
        case 'php4':
        case 'php5':
        case 'phps':
        case 'phtml':
            $img = 'code';
            break;
        case 'htm':
        case 'html':
        case 'shtml':
        case 'xhtml':
            $img = 'html';
            break;
        case 'xml':
        case 'xsl':
            $img = 'excel';
            break;
        case 'wav':
        case 'mp3':
        case 'mp2':
        case 'm4a':
        case 'aac':
        case 'ogg':
        case 'oga':
        case 'wma':
        case 'mka':
        case 'flac':
        case 'ac3':
        case 'tds':
            $img = 'music';
            break;
        case 'm3u':
        case 'm3u8':
        case 'pls':
        case 'cue':
            $img = 'music2';
            break;
        case 'avi':
        case 'mpg':
        case 'mpeg':
        case 'mp4':
        case 'm4v':
        case 'flv':
        case 'f4v':
        case 'ogm':
        case 'ogv':
        case 'mov':
        case 'mkv':
        case '3gp':
        case 'asf':
        case 'wmv':
            $img = 'video';
            break;
        case 'eml':
        case 'msg':
            $img = 'mail';
            break;
        case 'xls':
        case 'xlsx':
            $img = 'excel';
            break;

        case 'bak':
            $img = 'paste';
            break;
        case 'doc':
        case 'docx':
            $img = 'word';
            break;
        case 'ppt':
        case 'pptx':
            $img = 'ppt';
            break;
        case 'ttf':
        case 'ttc':
        case 'otf':
        case 'woff':
        case 'woff2':
        case 'eot':
        case 'fon':
            $img = 'font';
            break;
        case 'pdf':
            $img = 'pdf';
            break;
        case 'psd':
        case 'ai':
        case 'eps':
        case 'fla':
        case 'swf':
            $img = 'picture';
            break;
        case 'exe':
        case 'msi':
            $img = 'file';
            break;
        case 'bat':
            $img = 'terminal';
            break;
        default:
            $img = 'question';
    }
    return "fi-$img";
}
/**
 * Get image files extensions
 * @return array
 */
function fm_get_image_exts()
{
    return array('ico', 'gif', 'jpg', 'jpeg', 'jpc', 'jp2', 'jpx', 'xbm', 'wbmp', 'png', 'bmp', 'tif', 'tiff', 'psd');
}
/**
 * Get video files extensions
 * @return array
 */
function fm_get_video_exts()
{
    return array('webm', 'mp4', 'm4v', 'ogm', 'ogv', 'mov');
}
/**
 * Get audio files extensions
 * @return array
 */
function fm_get_audio_exts()
{
    return array('wav', 'mp3', 'ogg', 'm4a');
}
/**
 * Get text file extensions
 * @return array
 */
function fm_get_text_exts()
{
    return array(
        'txt', 'css', 'ini', 'conf', 'log', 'htaccess', 'passwd', 'ftpquota', 'sql', 'js', 'jsx', 'json', 'sh', 'config',
        'php', 'php4', 'php5', 'phps', 'phtml', 'htm', 'html', 'shtml', 'xhtml', 'xml', 'xsl', 'm3u', 'm3u8', 'pls', 'cue',
        'eml', 'msg', 'csv', 'bat', 'twig', 'tpl', 'md', 'gitignore', 'less', 'sass', 'scss', 'c', 'cpp', 'cs', 'py',
        'map', 'lock', 'dtd', 'svg',
    );
}
/**
 * Get mime types of text files
 * @return array
 */
function fm_get_text_mimes()
{
    return array(
        'application/xml',
        'application/javascript',
        'application/x-javascript',
        'image/svg+xml',
        'message/rfc822',
    );
}
/**
 * Get file names of text files w/o extensions
 * @return array
 */
function fm_get_text_names()
{
    return array(
        'license',
        'readme',
        'authors',
        'contributors',
        'changelog',
    );
}
/**
 * Class to work with zip files (using ZipArchive)
 */
class FM_Zipper
{
    private $zip;
    public function __construct()
    {
        $this->zip = new ZipArchive();
    }
    /**
     * Create archive with name $filename and files $files (RELATIVE PATHS!)
     * @param string $filename
     * @param array|string $files
     * @return bool
     */
    public function create($filename, $files)
    {
        $res = $this->zip->open($filename, ZipArchive::CREATE);
        if ($res !== true) {
            return false;
        }
        if (is_array($files)) {
            foreach ($files as $f) {
                if (!$this->addFileOrDir($f)) {
                    $this->zip->close();
                    return false;
                }
            }
            $this->zip->close();
            return true;
        } else {
            if ($this->addFileOrDir($files)) {
                $this->zip->close();
                return true;
            }
            return false;
        }
    }
    /**
     * Extract archive $filename to folder $path (RELATIVE OR ABSOLUTE PATHS)
     * @param string $filename
     * @param string $path
     * @return bool
     */
    public function unzip($filename, $path)
    {
        $res = $this->zip->open($filename);
        if ($res !== true) {
            return false;
        }
        if ($this->zip->extractTo($path)) {
            $this->zip->close();
            return true;
        }
        return false;
    }
    /**
     * Add file/folder to archive
     * @param string $filename
     * @return bool
     */
    private function addFileOrDir($filename)
    {
        if (is_file($filename)) {
            return $this->zip->addFile($filename);
        } elseif (is_dir($filename)) {
            return $this->addDir($filename);
        }
        return false;
    }
    /**
     * Add folder recursively
     * @param string $path
     * @return bool
     */
    private function addDir($path)
    {
        if (!$this->zip->addEmptyDir($path)) {
            return false;
        }
        $objects = scandir($path);
        if (is_array($objects)) {
            foreach ($objects as $file) {
                if ($file != '.' && $file != '..') {
                    if (is_dir($path . '/' . $file)) {
                        if (!$this->addDir($path . '/' . $file)) {
                            return false;
                        }
                    } elseif (is_file($path . '/' . $file)) {
                        if (!$this->zip->addFile($path . '/' . $file)) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
}
function getFileURL($path)
{
    return (strpos($path, FM_PUBLIC_HTML) == -1) ?
        empty(FM_ROOT_URL) ?
        FM_SELF_URL . "?getFile=" . $path :
        str_replace(FM_ROOT_PATH, FM_ROOT_URL, $path) :
        str_replace(FM_PUBLIC_HTML, FM_BASE_URL, $path);
}

   //--- templates functions
/**
 * Show nav block
 * @param string $path
 */
function fm_show_nav_path($path, $buttons = "")
{
    ?>
          <ul id="slide-out" class="sidenav">
          <?php if (!FM_READONLY) : ?>


<?php 
echo empty($buttons) ? '' : $buttons . '<li><div class="divider"></div></li>'; ?>
<div class="hide-on-large-only">

             <li><a class="waves waves-green
" title="New folder" href="#createNewItem">&#xf0fe; New folder</a></li>
            <?php endif; ?>
            <?php if (!FM_READONLY) : ?>
            <li><a title="Upload files" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;upload=1">&#xf0ee; Upload files</a></li>
            <?php endif; ?>
            <li><a title="Issues" href="?p=&issues=1">! Issues</a></li>
            <?php if (FM_USE_AUTH) : ?><li><a class="waves waves-red
" title="Logout" href="?logout=1">&#xf08b; Logout</a></li><?php endif; ?>
            <li><div class="divider"></div></li>
            </div>

</ul>
        <nav>
        <div class="nav-wrapper blue lighten-1">
            <div class="col s12">
            <a href="#slide-out" id="snt" class="sidenav-trigger">&#xe3c7;</a>
        <?php
        $path = fm_clean_path($path);
        $root_url = "<a href='?p=" . "' title='Home' class='breadcrumb'>&#xf015;</a>";
        $sep = '';
        if ($path != '') {
            $exploded = explode('/', $path);
            $count = count($exploded);
            $array = array();
            $parent = '';
            for ($i = 0; $i < $count; $i++) {
                $parent = trim($parent . '/' . $exploded[$i], '/');
                $parent_enc = urlencode($parent);
                $array[] = "<a href='?p={$parent_enc}" . "' class='breadcrumb'>" . fm_enc(fm_convert_win($exploded[$i])) . "</a>";
            }
            $root_url .= $sep . implode($sep, $array);
        }
        echo '<div class="break-word float-left">' . $root_url . '</div>';
        ?>

        <div class="float-right">

        </div>
        <ul class="right hide-on-med-and-down">
                <?php echo $buttons; ?>
                <?php if (!FM_READONLY) : ?>
             
             <li><a title="New folder" href="#createNewItem">&#xf0fe;</a></li>
             <?php endif; ?>
             <?php if (!FM_READONLY) : ?>

             <li><a title="Upload files" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;upload=1">&#xf0ee;</a></li>
             <?php endif; ?>
             <li><a title="Issues" href="?p=&issues=1">!</a></li>
            <?php if (FM_USE_AUTH) : ?><li><a title="Logout" href="?logout=1">&#xf08b;</a></li><?php endif; ?>
        </ul>
        </div>
        </div>
            </nav>
        <?php

    }
    /**
     * Show message from session
     */
    function fm_show_message()
    {
        if (isset($_SESSION['message'])) {
            foreach ($_SESSION['message'] as $msg) {
                $class = isset($msg[1]) ? $msg[1] : 'ok';
                echo '<div class="alert"><p class="message ' . $msg[1] . '">' . $msg[0] . '  <span class="closebtn" onclick="this.parentElement.style.display=' . "'none'" . ';">&times;</span></p> </div>';
            }
            unset($_SESSION['message']);
        }
    }
    /**
     * Show page header in Login Form
     */
    function fm_show_header_login()
    {
        $sprites_ver = '20160315';
        header("Content-Type: text/html; charset=utf-8");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        header("Pragma: no-cache");
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title><?php echo FM_TITLE; ?></title>
            <meta name="Description" CONTENT="<?php echo FM_DESC; ?>">
            <link rel="icon" href="src/favicon.png">
            <link rel="shortcut icon" href="src/favicon.png">

            <!--Let browser know website is optimized for mobile-->
            <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
            <link rel="stylesheet" href="src/main.css">
        </head>
        <body>
                <?php

            }
            /**
             * Show page footer in Login Form
             */
            function fm_show_footer_login()
            {
                ?>
                <script src="src/main.js"></script>

        </body>
        </html>
<?php

}
/**
 * Show page header
 */
function fm_show_header()
{
    $sprites_ver = '20160315';
    header("Content-Type: text/html; charset=utf-8");
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
    header("Pragma: no-cache");
    //header("Content-Security-Policy: script-src " . FM_BASE_URL . " https://cdnjs.cloudflare.com, unsafe-inline");
    ?>
        <!DOCTYPE html>
        <html class="nojs">
        <head>
            <meta charset="utf-8">
            <meta property="fm:path" value="<?php echo fm_enc(FM_PATH); ?>">
            <meta property="fm:rootpath" value="<?php echo fm_enc(FM_ROOT_PATH); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="Description" CONTENT="<?php echo FM_DESC; ?>">

            <title><?php echo FM_TITLE; ?></title>
            <script>document.documentElement.className="js"</script>
            <link rel="icon" href="src/favicon.png">
            <link rel="shortcut icon" href="src/favicon.png">
            <?php if (isset($_GET['view']) && FM_USE_HIGHLIGHTJS) : ?>
            <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.2.0/styles/<?php echo FM_HIGHLIGHTJS_STYLE ?>.min.css">
            <?php endif; ?>

            <link rel="stylesheet" href="src/main.css">


        </head>
        <body>
                <?php if (!FM_READONLY) : ?>
                <div id="createNewItem" class="modal">
                    <div class="modal-content">
                    <a href="#close" title="Close" class="close">X</a>
                    <h2>Create New Item</h2>
                    <form action='' method='GET'>
                        <p>Item Type &nbsp; : </p>
                        <input type='hidden' name='p' value="<?php echo fm_enc(FM_PATH); ?>">
                        <label>
                        <input type="radio" name="type" id="newfile" value="file" onclick='get("#Fname").innerHTML=(this.checked?"File":"Folder")+" Name"' checked>
                        <span>File</span>
                        </label>
                        <label>
                        <input type="radio" name="type" value="folder" onclick='get("#Fname").innerHTML=(this.checked?"Folder":"File")+" Name"'> 
                        <span>Folder</span>
                        </label>
                        <div class='input-field'>
                            <input type="text" name="new" id="newfilename" value="">
                            <label for="newfilename" id="Fname">File Name </label>
                        </div>
                        <input type="submit" name="submit" class="group-btn btn waves waves-light" value="Create Now">
                    </form>
                    </div>
                </div>
                
            <?php endif; ?>
         <?php

    }
    /**
     * Show page footer
     */
    function fm_show_footer()
    {
        ?>
      <script src="src/main.js"></script>
   </body>
</html>
<?php

}

?>