window.M = {
    keys: {
        TAB: 9,
        ARROW_UP: 38,
        ARROW_DOWN: 40
    },
    tabPressed: false,
    keyDown: false
};
(function ($) {
    // Function to update labels of text fields
    M.updateTextFields = function () {
        let input_selector =
            'input[type=text], input[type=password]';
        $(input_selector).each(function (element, index) {
            let $this = $(this);
            if (
                element.value.length > 0 ||
                $(element).is(':focus') ||
                element.autofocus ||
                $this.attr('placeholder') !== null
            ) {
                $this.siblings('label').addClass('active');
            } else if (element.validity) {
                $this.siblings('label').toggleClass('active', element.validity.badInput === true);
            } else {
                $this.siblings('label').removeClass('active');
            }
        });
    };

    M.validate_field = function (object) {
        let hasLength = object.attr('data-length') !== null;
        let lenAttr = parseInt(object.attr('data-length'));
        let len = object[0].value.length;

        if (len === 0 && object[0].validity.badInput === false && !object.is(':required')) {
            if (object.hasClass('validate')) {
                object.removeClass('valid');
                object.removeClass('invalid');
            }
        } else {
            if (object.hasClass('validate')) {
                // Check for character counter attributes
                if (
                    (object.is(':valid') && hasLength && len <= lenAttr) ||
                    (object.is(':valid') && !hasLength)
                ) {
                    object.removeClass('invalid');
                    object.addClass('valid');
                } else {
                    object.removeClass('valid');
                    object.addClass('invalid');
                }
            }
        }
    };



    $(document).ready(function () {
        // Text based inputs
        let input_selector =
            'input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=number], input[type=search], input[type=date], input[type=time], textarea';

        // Add active if form auto complete
        $(document).on('change', input_selector, function () {
            if (this.value.length !== 0 || $(this).attr('placeholder') !== null) {
                $(this)
                    .siblings('label')
                    .addClass('active');
            }
            M.validate_field($(this));
        });
        function handleEmoji(t) {
            ajax(function () {
                location.reload();
            }, `commentId=${t.parent('comment').attr('data-id')}&reaction=${t.attr('data-emoji')}`);
        }
        var editingIns;
        $(document).on('mousedown', function (e) {
            let t = $(e.target);
            if (t.is(".resp-choose>*")) {
                t.closest(".resp-trigger").addClass("focus");
                handleEmoji(t);
            } else if (t.is(".resp-trigger")) {
                t.toggleClass("focus");
                t[0].blur();
            } else if (t.is(".emoji-counter")) {
                handleEmoji(t);
            } else if (t.is("a.editBtn")) {
                let c = t.parent(".comment");
                if (c.attr('data-edit') == 1) {
                    c.attr('data-edit', 1);
                    c.find(".body").html("<textarea id='editTxt'>" + c.attr('data-raw') + "</textarea>");
                    t.html("Save!");
                    editingIns = new SimpleMDE({
                        element: $("#editTxr")[0],
                        status: false,
                        toolbar: false,
                    });
                } else {
                    ajax(function () {
                        editingIns = null;
                        location.reload();
                    }, `commentId=${c.attr('data-id')}&newVal=${editingIns.value()}`);
                }

            } else {
                $(".resp-trigger").removeClass('focus');
            }

        });
        // Add active if input element has been pre-populated on document ready
        $(document).ready(function () {
            M.updateTextFields();
        });

        // HTML DOM FORM RESET handling
        $(document).on('reset', function (e) {
            let formReset = $(e.target);
            if (formReset.is('form')) {
                formReset
                    .find(input_selector)
                    .removeClass('valid')
                    .removeClass('invalid');
                formReset.find(input_selector).each(function (e) {
                    if (this.value.length) {
                        $(this)
                            .siblings('label')
                            .removeClass('active');
                    }
                });

                // Reset select (after native reset)
                setTimeout(function () {
                    formReset.find('select').each(function () {
                        // check if initialized
                        if (this.M_FormSelect) {
                            $(this).trigger('change');
                        }
                    });
                }, 0);
            }
        });

        /**
         * Add active when element has focus
         * @param {Event} e
         */
        document.addEventListener(
            'focus',
            function (e) {
                if ($(e.target).is(input_selector)) {
                    $(e.target)
                        .siblings('label, .prefix')
                        .addClass('active');
                }
            },
            true
        );

        /**
         * Remove active when element is blurred
         * @param {Event} e
         */
        document.addEventListener(
            'blur',
            function (e) {
                let $inputElement = $(e.target);
                if ($inputElement.is(input_selector)) {
                    let selector = '.prefix';

                    if (
                        $inputElement[0].value.length === 0 &&
                        $inputElement[0].validity.badInput !== true &&
                        $inputElement.attr('placeholder') === null
                    ) {
                        selector += ', label';
                    }
                    $inputElement.siblings(selector).removeClass('active');
                    M.validate_field($inputElement);
                }
            },
            true
        );

        // Radio and Checkbox focus class
        let radio_checkbox = 'input[type=radio], input[type=checkbox]';
        $(document).on('keyup', radio_checkbox, function (e) {
            // TAB, check if tabbing to radio or checkbox.
            if (e.which === M.keys.TAB) {
                $(this).addClass('tabbed');
                let $this = $(this);
                $this.one('blur', function (e) {
                    $(this).removeClass('tabbed');
                });
                return;
            }
        });





    }); // End of $(document).ready
})(cash);
