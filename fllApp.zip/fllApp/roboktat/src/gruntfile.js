module.exports = function (grunt) {

    // 1. All configuration goes here
    grunt.initConfig({
        "pkg": grunt.file.readJSON("package.json"),
        "concat": {
            "css": {
                "src": ["css/*.css"],
                "dest": "main.css"
            },
            "js": {
                "src": ["js/cash.js", "js/*.js"],
                "dest": "main.js"
            }
        },
        "cssmin": {
            "css": {
                "src": "main.css",
                "dest": "main.css"
            }
        },

        "uglify": {
            "js": {
                "src": "main.js",
                "dest": "main.js"
            }
        }

    });

    // 2. Where we tell Grunt we plan to use this plug-in.
    grunt.loadNpmTasks("grunt-contrib-concat");
    grunt.loadNpmTasks("grunt-contrib-cssmin");
    grunt.loadNpmTasks("grunt-contrib-uglify-es");


    // 3. Where we tell Grunt what to do when we type "grunt" into the terminal.
    grunt.registerTask("default", ["concat", "cssmin", "uglify"]);
    grunt.registerTask("devBuild", ["concat"]);


};
